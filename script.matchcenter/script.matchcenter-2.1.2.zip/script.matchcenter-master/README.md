# script.matchcenter
![Logo](https://raw.githubusercontent.com/enen92/script.matchcenter/master/icon.png)

This addon brings a window that can be mapped to a remote key to show livescores for the current live football games, access match information (goals, cards, subs, lineups) or follow what others are saying about the match in twitter.

**Powered by:** http://www.thesportsdb.com

**Screenshots**
![1](http://i.imgur.com/7jNhe1L.png)
![2](http://i.imgur.com/f59RKlE.png)
![3](http://i.imgur.com/wpYI1nz.png)
![4](http://i.imgur.com/mGlnvts.png)
![5](http://i.imgur.com/pbG6kxz.png)
![6](http://i.imgur.com/sAC466S.png)
![7](http://i.imgur.com/4hzvYUC.png)
![8](http://i.imgur.com/NR375Y3.png)
![9](http://i.imgur.com/omZ9gqD.png)
![10](http://i.imgur.com/5Aamq5f.png)
![11](http://i.imgur.com/nDUYfWB.png)
![12](http://i.imgur.com/DARAuIK.png)
![13](http://i.imgur.com/E2Au3rv.png)
# -*- coding: utf-8 -*-
#---------------------------------------------------------------------------
# Plugin Tools v1.0.8
#---------------------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube, parsedom and pelisalacarta addons
# Author: 
# Jesús
# tvalacarta@gmail.com
# http://www.mimediacenter.info/plugintools
#---------------------------------------------------------------------------
# Changelog:
# 1.0.0
# - First release
# 1.0.1
# - If find_single_match can't find anything, it returns an empty string
# - Remove addon id from this module, so it remains clean
# 1.0.2
# - Added parameter on "add_item" to say that item is playable
# 1.0.3
# - Added direct play
# - Fixed bug when video isPlayable=True
# 1.0.4
# - Added get_temp_path, get_runtime_path, get_data_path
# - Added get_setting, set_setting, open_settings_dialog and get_localized_string
# - Added keyboard_input
# - Added message
# 1.0.5
# - Added read_body_and_headers for advanced http handling
# - Added show_picture for picture addons support
# - Added optional parameters "title" and "hidden" to keyboard_input
# 1.0.6
# - Added fanart, show, episode and infolabels to add_item
# 1.0.7
# - Added set_view function
# 1.0.8
# - Added selector
#---------------------------------------------------------------------------
import xbmc,xbmcplugin,xbmcaddon,xbmcgui,re,sys,os,time,socket,gzip
from io import StringIO
module_log_enabled=False; http_debug_log_enabled=False; LIST="list"; THUMBNAIL="thumbnail"; MOVIES="movies"; TV_SHOWS="tvshows"; SEASONS="seasons"; EPISODES="episodes"; OTHER="other"; 
# Suggested view codes for each type from different skins (initial list thanks to xbmcswift2 library)
try: import urllib.parse as urlparse
except: import urllib as urlparse


def find_multiple_matches(text,pattern): matches=re.findall(pattern,text,re.DOTALL); return matches # Parse string and extracts multiple matches using regular expressions
def find_single_match(text,pattern): # Parse string and extracts first match as a string
    result=""
    try: matches=re.findall(pattern,text,flags=re.DOTALL); result=matches[0]
    except: result=""
    return result


f=open(os.path.join(os.path.dirname(__file__),"addon.xml")); data=f.read(); f.close()
addon_id=find_single_match(data,'id="([^"]+)"')
if addon_id=="": addon_id=find_single_match(data,"id='([^']+)'")
__settings__=xbmcaddon.Addon(id=addon_id); __language__=__settings__.getLocalizedString

def close_item_list(): xbmcplugin.endOfDirectory(handle=int(sys.argv[1]),succeeded=True)
def get_runtime_path(): dev=xbmc.translatePath(__settings__.getAddonInfo('Path'));  return dev
def get_setting(name): dev=__settings__.getSetting(name); return dev
def set_setting(name,value):  __settings__.setSetting( name,value )
def open_settings_dialog():  __settings__.openSettings()

def get_params(): # Parse XBMC params - based on script.module.parsedom addon    
    param_string=sys.argv[2]; commands={}
    if param_string:
        split_commands=param_string[param_string.find('?') + 1:].split('&')
        for command in split_commands:
            if len(command) > 0:
                if "=" in command: split_command=command.split('='); key=split_command[0]; value=urlparse.unquote_plus(split_command[1]); commands[key]=value
                else: commands[command]=""
    return commands
# Fetch text content from an URL


def add_item(action="",title="",plot="",url="",thumbnail="",fanart="",show="",episode="",extra="",page="",info_labels=None,isPlayable=False,folder=True):
    contextMenuItems = []
    #_log("add_item action=["+action+"] title=["+title+"] url=["+url+"] thumbnail=["+thumbnail+"] fanart=["+fanart+"] show=["+show+"] episode=["+episode+"] extra=["+extra+"] page=["+page+"] isPlayable=["+str(isPlayable)+"] folder=["+str(folder)+"]")
    listitem=xbmcgui.ListItem(title)
    listitem.setArt({'thumb' : thumbnail})
    if info_labels is None: info_labels={"Title":title,"FileName":title,"Plot":plot}
    listitem.setInfo( "video", info_labels )
    if fanart!="": listitem.setProperty('fanart_image',fanart); xbmcplugin.setPluginFanart(int(sys.argv[1]),fanart)
    if url.startswith("plugin://"): itemurl=url; listitem.setProperty('IsPlayable','true'); xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=itemurl,listitem=listitem,isFolder=folder)
    elif isPlayable: listitem.setProperty("Video","true"); listitem.setProperty('IsPlayable','true'); itemurl='%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % (sys.argv[0],action,urlparse.quote_plus(title),urlparse.quote_plus(url),urlparse.quote_plus(thumbnail),urlparse.quote_plus(plot),urlparse.quote_plus(extra),urlparse.quote_plus(page)); xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=itemurl,listitem=listitem,isFolder=folder)
    else: itemurl='%s?action=%s&title=%s&url=%s&thumbnail=%s&plot=%s&extra=%s&page=%s' % (sys.argv[0],action,urlparse.quote_plus(title),urlparse.quote_plus(url),urlparse.quote_plus(thumbnail),urlparse.quote_plus(plot),urlparse.quote_plus(extra),urlparse.quote_plus(page)); xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=itemurl,listitem=listitem,isFolder=folder)


def get_localized_string(code):
    dev=__language__(code)
    try: dev=dev.encode("utf-8")
    except: pass
    return dev
    
    
def set_view(view_mode):
    if view_mode==MOVIES: xbmcplugin.setContent( int(sys.argv[1]) ,"movies" )
    elif view_mode==TV_SHOWS:  xbmcplugin.setContent( int(sys.argv[1]) ,"tvshows" )
    elif view_mode==SEASONS: xbmcplugin.setContent( int(sys.argv[1]) ,"seasons" )
    elif view_mode==EPISODES:  xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )

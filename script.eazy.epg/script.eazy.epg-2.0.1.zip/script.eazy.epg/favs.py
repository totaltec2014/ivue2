def main():
                import sys,re,os,xbmc

                favourites=xbmc.translatePath('special://profile/favourites.xml')
                s=open(favourites).read()
   
                s=s.replace('[COLOR white]', '')
                s=s.replace('[COLOR blue]', '')
                s=s.replace('[COLOR red]', '')
                s=s.replace(' [HD]', '')
                s=s.replace('[COLOR yellow]', '')
                s=s.replace('[COLOR green]', '')
                s=s.replace('[COLOR  limegreen]', '')
                s=s.replace(' Duel Audio', '')           
                s=s.replace('[B]', '')
                s=s.replace('[/B]', '')
                s=s.replace('[/COLOR]', '')
                s=s.replace(' SD', '')
                s=s.replace(' : UK', '')
                s=s.replace('UK ', '')
                s=s.replace(' : US', '')
                s=s.replace('-UK', '')
                s=s.replace(' HD+', '')
                s=s.replace(' HDS', '')
                s=s.replace(" : INT", '')
                s=s.replace(' HD  ', '')
                s=s.replace(' HD', '')
                s=s.replace('*', '')
                s=s.replace('- ', '')
                s=s.replace('-', ' ')
                s=s.replace(' HQ', '')                
                s=s.replace('UK : ', '')
                s=s.replace(' (Top10)', '')
                s=s.replace(' (US)', '')
                s=s.replace(' (IN)', '')
                s=s.replace(' (English)', '')
                s=s.replace(' (Sports)', '')
                s=s.replace(' (Music)', '')
                s=s.replace(' (Documentary)', '')
                s=s.replace(' TEST', '')
                s=s.replace('Test: ', '')
                s=s.replace('Test : ', '')
                s=s.replace(' (FR)', '')
                s=s.replace(' (AR)', '')
                s=s.replace(' (SA)', '')
                s=s.replace(' (JU)', '')
                s=s.replace(' (JH)', '')
                s=s.replace(' (MO)', '')
                s=s.replace(' (French)', '')
                s=s.replace(' 1080p', '')
                s=s.replace(' 720p', '')
                s=s.replace(' (Arabic)', '')
                s=s.replace(' (Spanish)', '')
                s=s.replace(' (Serbian)', '')
                s=s.replace(' (RS)', '')
                s=s.replace(' (RU)', '')
                s=s.replace(' (QA)', '')
                s=s.replace(' (Family)', '')
                s=s.replace(' (Movie Channels)', '')
                s=s.replace(' (News)', '')
                s=s.replace(' (Entertainment)', '')
                s=s.replace(' (UK)', '')
                s=s.replace(' (Maybe Geo-Blocked)', '')                

                s=s.replace('BBC ONE : UK','BBC One')
                s=s.replace('bbc1','BBC One')
                s=s.replace('BBC One London ','BBC One')
                s=s.replace('bbc 1','BBC One')
                s=s.replace('BBC 1','BBC One')
                s=s.replace('bbc one','BBC One')
                s=s.replace('BBC ONE','BBC One')



                s=s.replace('BBC 2 : UK','BBC Two')
                s=s.replace('BBC TWO : UK','BBC Two')
                s=s.replace('BBC Two England ','BBC Two')
                s=s.replace('bbc2','BBC Two')
                s=s.replace('bbc 2','BBC Two')
                s=s.replace('BBC 2','BBC Two')
                s=s.replace('BBCTWO','BBC Two')
                s=s.replace('BBC TWO','BBC Two')

                s=s.replace('ITV London','ITV1')
                s=s.replace('ITV1 : UK','ITV1')
                s=s.replace('itv 1','ITV1')
                s=s.replace('ITV 1','ITV1')
                s=s.replace('Itv 1','ITV1')
                s=s.replace('ITV : UK','ITV1')
                s=s.replace('Itv1','ITV1')


                s=s.replace('CHANNEL 4 : UK','Channel 4')
                s=s.replace('CHANNEL4','Channel 4')
                s=s.replace('CHANNEL 4','Channel 4')
                s=s.replace('channel 4','Channel 4')
                s=s.replace('channel4','Channel 4')

                s=s.replace('CHANNEL 5 : UK','Channel 5')
                s=s.replace('CHANNEL5','Channel 5')
                s=s.replace('CHANNEL 5','Channel 5')
                s=s.replace('channel 5','Channel 5')
                s=s.replace('channel5','Channel 5')

                s=s.replace('ITV2 : UK','ITV2')
                s=s.replace('itv 2','ITV2')
                s=s.replace('ITV 2','ITV2')
                s=s.replace('Itv 2','ITV2')
                s=s.replace('Itv2','ITV2')

                s=s.replace('ITV3 : UK','ITV3')
                s=s.replace('itv 3','ITV3')
                s=s.replace('ITV 3','ITV3')
                s=s.replace('Itv 3','ITV3')
                s=s.replace('Itv3','ITV3')

                s=s.replace('ITV4 : UK','ITV4')
                s=s.replace('itv 4','ITV4')
                s=s.replace('ITV 4','ITV4')
                s=s.replace('Itv 4','ITV4')
                s=s.replace('Itv4','ITV4')

                s=s.replace('ITV1+1 : UK','ITV1 +1')
                s=s.replace('itv1+1','ITV1 +1')
                s=s.replace('ITV1+1','ITV1 +1')
                s=s.replace('Itv1+1','ITV1 +1')
                s=s.replace('Itv1+1','ITV1 +1')

                s=s.replace('ITV2+1 : UK','ITV2 +1')
                s=s.replace('itv2+1','ITV2 +1')
                s=s.replace('ITV2+1','ITV2 +1')
                s=s.replace('Itv2+1','ITV2 +1')
                s=s.replace('Itv2+1','ITV2 +1')

                s=s.replace('ITV3+1 : UK','ITV3 +1')
                s=s.replace('itv3+1','ITV3 +1')
                s=s.replace('ITV3+1','ITV3 +1')
                s=s.replace('Itv3+1','ITV3 +1')
                s=s.replace('Itv3+1','ITV3 +1')

                s=s.replace('ITV4+1 : UK','ITV4 +1')
                s=s.replace('itv4+1','ITV4 +1')
                s=s.replace('ITV4+1','ITV4 +1')
                s=s.replace('Itv4+1','ITV4 +1')
                s=s.replace('Itv4+1','ITV4 +1')

                s=s.replace('ITV ENCORE : UK','ITV Encore')
                s=s.replace('itv ENCORE','ITV Encore')
                s=s.replace('ITVENCORE','ITV Encore')
                s=s.replace('Itv encore','ITV Encore')
                s=s.replace('itv encore','ITV Encore')

                s=s.replace('itvbe','ITVBe')
                s=s.replace('ITVBE','ITVBe')
                s=s.replace('ITVBe : UK','ITVBe')

                s=s.replace('E4 : UK','E4')
                s=s.replace('E4','E4')
                s=s.replace('e4','E4')

                s=s.replace('MORE 4 : UK','More4')
                s=s.replace('More4 : UK','More4')
                s=s.replace('MORE 4','More4')
                s=s.replace('more 4','More4')
                s=s.replace('More 4','More4')

                s=s.replace('4SEVEN : UK','4seven')
                s=s.replace('4SEVEN','4seven')
                s=s.replace('4seven','4seven')
                s=s.replace('4 seven','4seven')
                s=s.replace('4 SEVEN','4seven')

                s=s.replace('5STAR : UK','5 Star')
                s=s.replace('5STAR','5 Star')
                s=s.replace('5 STAR','5 Star')
                s=s.replace('5 star','5 Star')
                s=s.replace('5 star : UK','5 Star')
                s=s.replace('5*','5 Star')

                s=s.replace('5USA : UK','5USA')
                s=s.replace('5 USA','5USA')
                s=s.replace('5usa','5USA')
                s=s.replace('5 usa','5USA')

                s=s.replace('BBC3 : UK','BBC THREE')
                s=s.replace('BBC THREE : UK','BBC THREE')
                s=s.replace('BBC 3','BBC THREE')
                s=s.replace('BBC3','BBC THREE')
                s=s.replace('Bbc 3','BBC THREE')
                s=s.replace('Bbc3','BBC THREE')
                s=s.replace('BBCTHREE','BBC THREE')
                s=s.replace('bbc three','BBC THREE')
                s=s.replace('bbc3','BBC THREE')

                s=s.replace('BBC4 : UK','BBC FOUR')
                s=s.replace('BBC FOUR : UK','BBC FOUR')
                s=s.replace('BBC 4','BBC FOUR')
                s=s.replace('BBC4','BBC FOUR')
                s=s.replace('Bbc 4','BBC FOUR')

                s=s.replace('Bbc4','BBC FOUR')
                s=s.replace('BBCFOUR','BBC FOUR')
                s=s.replace('bbc four','BBC FOUR')
                s=s.replace('bbc4','BBC FOUR')

                s=s.replace('EDEN : UK','EDEN')
                s=s.replace('eden','EDEN')

                s=s.replace('RTE ONE : UK','RTE One')
                s=s.replace('RTE ONE','RTE One')
                s=s.replace('RTEONE','RTE One')
                s=s.replace('rte one','RTE One')
                s=s.replace('Rte one','RTE One')
                s=s.replace('rteone','RTE One')
                s=s.replace('rte1','RTE One')
                s=s.replace('rte 1','RTE One')

                s=s.replace('RTE TWO : UK','RTE Two')
                s=s.replace('RTE TWO','RTE Two')
                s=s.replace('RTETWO','RTE Two')
                s=s.replace('rte two','RTE Two')
                s=s.replace('Rte two','RTE Two')
                s=s.replace('rtetwo','RTE Two')
                s=s.replace('rte2','RTE Two')
                s=s.replace('rte 2','RTE Two')

                s=s.replace('RTE NEWS NOW : UK','RTE News Now')
                s=s.replace('RTE NEWS NOW',' RTE News Now')
                s=s.replace('RTE NEWS','RTE News Now')
                s=s.replace('rte news now','RTE News Now')
                s=s.replace('Rte news','RTE News Now')
                s=s.replace('rte news','RTE News Now')
                        
                s=s.replace('3E : UK','3e')
                s=s.replace('3E','3e')
                s=s.replace('3 e','3e')

                s=s.replace('TV3 : UK','TV3')
                s=s.replace('tv3','TV3')
                s=s.replace('TV 3','TV3')

                s=s.replace('TG4 : UK','TG4')
                s=s.replace('tg4','TG4')
                s=s.replace('TV 3','TV3')

                s=s.replace('UTV : UK','UTV')
                s=s.replace('utv','UTV')
                s=s.replace('UTV IE','UTV')

                s=s.replace('IRISH TV : UK','irish TV')
                s=s.replace('IRISH TV','irish TV')
                s=s.replace('irish tv','irish TV')

                s=s.replace('TV3 : UK','TV3')
                s=s.replace('tv3','TV3')
                s=s.replace('TV 3','TV3')

                s=s.replace('e!','E! entertainment', 1)
                s=s.replace('E!','E! entertainment', 1)

                s=s.replace('PICK : UK','Pick')
                s=s.replace('pick','Pick')
                s=s.replace('PICK','Pick')

                s=s.replace('WATCH : UK','Watch')
                s=s.replace('WATCH','Watch')
                s=s.replace('watch','Watch')

                s=s.replace('GOLD : UK','gold')
                s=s.replace('GOLD','gold')
                s=s.replace('Gold','gold')

                s=s.replace('DAVE : UK','Dave')
                s=s.replace('dave : UK','Dave')
                s=s.replace('DAVE','Dave')
                s=s.replace('dave','Dave')

                s=s.replace('TRUTV : UK','truTV')
                s=s.replace('TRUTV','truTv')
                s=s.replace('turtv','truTV')

                s=s.replace('SKY ONE : UK','Sky1')
                s=s.replace('SKY ONE','Sky1')
                s=s.replace('sky one','Sky1')
                s=s.replace('SKY1','Sky1')
                s=s.replace('sky1','Sky1')
                s=s.replace('SKY 1','Sky1')
                s=s.replace('sky 1','Sky1')

                s=s.replace('SKY TWO : UK','Sky2')
                s=s.replace('SKY TWO','Sky2')
                s=s.replace('sky two','Sky2')
                s=s.replace('SKY2','Sky2')
                s=s.replace('sky2','Sky2')
                s=s.replace('SKY 2','Sky2')
                s=s.replace('sky 2','Sky2')

                s=s.replace('SKY LIVING : UK','Sky Living')
                s=s.replace('SKY LIVING','Sky Living')
                s=s.replace('sky living','Sky Living')

                s=s.replace('SKY ATLANTIC : UK','Sky Atlantic')
                s=s.replace('SKY ATLANTIC','Sky Alantic')
                s=s.replace('sky atlanic','Sky Alantic')

                s=s.replace('UNIVERSAL CHANNEL : UK','Univesal Channel')
                s=s.replace('UNIVERSAL CHANNEL','Univesal Channel')
                s=s.replace('universal channel','Univesal Channel')

                s=s.replace('SPIKE : UK','Spike')
                s=s.replace('SPIKE HD : US','Spike')
                s=s.replace('SPIKE','Spike')
                s=s.replace('spike','Spike')

                s=s.replace('HOME : UK','Home')
                s=s.replace('HOME','Home')
                s=s.replace('home','Home')

                s=s.replace('GOOD FOOD : UK','Good Food UK')
                s=s.replace('GOOD FOOD','Good Food UK')
                s=s.replace('good food','Good Food UK')

                s=s.replace('FOOD NETWORK : UK','Food Network')
                s=s.replace('FOOD NETWORK','Food Network')
                s=s.replace('food network','Food Network')

                s=s.replace('VIVA : UK','VIVA')
                s=s.replace('viva','VIVA')
                s=s.replace('Viva','VIVA')

                s=s.replace('VINTAGE TV : UK','Vintage TV')
                s=s.replace('VINTAGE TV','Vintage TV')
                s=s.replace('vintage tv','Vintage TV')

                s=s.replace('CHALLENGE : UK','Challenge')
                s=s.replace('CHALLENGE','Challenge')

                s=s.replace('SKY ARTS 1 : UK','Sky Arts 1')
                s=s.replace('SKY ARTS 1','Sky Arts 1')
                s=s.replace('sky arts one','Sky Arts 1')
                s=s.replace('sky arts 1','Sky Arts 1')
                s=s.replace('Sky Arts One','Sky Arts 1')
                s=s.replace('SKY ARTS ONE','Sky Arts 1')

                s=s.replace('REALLY : UK','Really')
                s=s.replace('REALLY','Really')
                s=s.replace('really','Really')

                s=s.replace('DMAX : UK','DMAX')
                s=s.replace('dmax','DMAX')

                s=s.replace('LONDON LIVE : UK','London Live')
                s=s.replace('london live','London Live')
                s=s.replace('LONDON LIVE','London Live')

                s=s.replace('DISCOVERY SHED : UK','Discovery Shed')
                s=s.replace('DISCOVERY SHED','Discovery Shed')
                s=s.replace('discovery shed','Discovery Shed')

                s=s.replace('DISCOVERY SCIENCE','Discovery Science')
                s=s.replace('discovery science','Discovery Science')
                s=s.replace('DISCOVERY SCIENCE ','Discovery Science')

                #s=s.replace('Discovery SCIence','Discovery Science')

                s=s.replace('DISCOVERY CHANNEL : UK','Discovery Channel')
                s=s.replace('DISCOVERY : UK','Discovery Channel')
                s=s.replace('DISCOVERY','Discovery Channel')
                s=s.replace('DISCOVERY CHANNEL','Discovery Channel')
                s=s.replace('discovery channel','Discovery Channel')
                s=s.replace('Discovery Channel : UK','Discovery Channel')

                s=s.replace('NAT GEO : UK','National Geographic Channel HD')
                s=s.replace('NAT GEO','National Geographic Channel HD')
                s=s.replace('NatGeo','National Geographic Channel HD')
                s=s.replace('NATIONAL GEOGRAPHIC CHANNEL','National Geographic Channel HD')
                s=s.replace('NATIONAL GEOGRAPHIC','National Geographic Channel HD')
                s=s.replace('national geographic','National Geographic Channel HD')

                s=s.replace('DISCOVERY TURBO : UK','Discovery Turbo')
                s=s.replace('DISCOVERY TURBO','Discovery Turbo')
                s=s.replace('discovery turbo','Discovery Turbo')

                s=s.replace('ANIMAL PLANET HD : UK','Animal Planet')
                s=s.replace('Animal Planet HD : UK','Animal Planet')
                s=s.replace('ANIMAL PLANET HD : US','Animal Planet')
                s=s.replace('ANIMAL PLANET','Animal Planet')
                s=s.replace('animal planet','Animal Planet')

                s=s.replace('National Geographic Channel HD WILD : UK','Nat Geo Wild')
                s=s.replace('National Geographic Channel WILD','Nat Geo Wild')
                s=s.replace('NAT GEO WILD','Nat Geo Wild')
                s=s.replace('nat geo wild','Nat Geo Wild')
                s=s.replace('NatGeoWild','Nat Geo Wild')


                s=s.replace('DISCOVERY HISTORY : UK','Discovery History')
                s=s.replace('DISCOVERY HISTORY','Discovery History')
                s=s.replace('discovery history','Discovery History')

                s=s.replace('DISCOVERY HOME AND HEALTH : UK','Discovery Home And Health')
                s=s.replace('DISCOVERY HOME AND HEALTH','Discovery Home And Health')
                s=s.replace('Discovery Home And Health : uk','Discovery Home And Health')

                s=s.replace('HISTORY2 (H2) HD : US','H2')
                s=s.replace('History 2','H2')
                s=s.replace('HISTORY2 (H2)','H2')

                s=s.replace('H2 : US','H2')
                s=s.replace('h2','H2')

                s=s.replace('DISCOVERY INVESTIGATION : UK','ID')
                s=s.replace('DISCOVERY INVESTIGATION','ID')
                s=s.replace('discovery investigation','ID')
                s=s.replace('ID: UK','ID')

                s=s.replace('CI : UK','CI')
                s=s.replace('CI','CI')
                s=s.replace('ci','CI')

                s=s.replace('QUEST : UK','QUEST')
                s=s.replace('Quest','QUEST')
                s=s.replace('quest','QUEST')

                s=s.replace('YESTERDAY : UK','YESTERDAY')
                s=s.replace('YESTERDAY','YESTERDAY')
                s=s.replace('yesterday','YESTERDAY')

                s=s.replace('CBS ACTION : UK','CBS Action')
                s=s.replace('CBS ACTION','CBS Action')
                s=s.replace('cbs action','CBS Action')

                s=s.replace('CBS DRAMA : UK','CBS Drama')
                s=s.replace('CBS DRAMA','CBS Drama')
                s=s.replace('cbs DRAMA','CBS Drama')

                s=s.replace('CBS REALITY : UK','CBS Reality')
                s=s.replace('CBS REALITY','CBS Reality')
                s=s.replace('cbs reality','CBS Reality')

                s=s.replace('CBS ACTION','CBS Action')
                s=s.replace('cbs action','CBS Action')

                s=s.replace('HISTORY : UK','HISTORY')
                s=s.replace('history','HISTORY')

                s=s.replace('fox : US','Fox')
                s=s.replace('FOX','fox')
                s=s.replace('fox','Fox')

                s=s.replace('UK : TLC HD','TLC')
                s=s.replace('TLC : UK','TLC')
                s=s.replace('TLC','TLC')
                s=s.replace('tlc','TLC')

                s=s.replace('HORROR CHANNEL : UK','Horror Channel')
                s=s.replace('HORROR CHANNEL','Horror Channel')
                s=s.replace('horror channel','horror channel')

                s=s.replace('SYFY HD : US','Syfy')
                s=s.replace('SYFY','Syfy')
                s=s.replace('Syfy : UK','Syfy')
                s=s.replace('Syfy : US','Syfy')
                s=s.replace('syfy','Syfy')

                s=s.replace('BRAVO : US','Bravo')
                s=s.replace('BRAVO','Bravo')

                s=s.replace('TRUE DRAMA : UK','True Drama')
                s=s.replace('TRUE DRAMA','True Drama')
                s=s.replace('true drama','True Drama')

                s=s.replace('TRUE ENTERTAINMENT : UK','True Entertainment')
                s=s.replace('TRUE ENTERTAINMENT','True Entertainment')
                s=s.replace('true entertainment','True Entertainment')

                s=s.replace('DRAMA : UK','Drama')
                s=s.replace('DRAMA','Drama')
                s=s.replace('drama','Drama')

                s=s.replace('COMEDY CENTRAL : UK','Comedy Central')
                s=s.replace('COMEDY CENTRAL','Comedy Central')
                s=s.replace('comedy central','Comedy Central')
                s=s.replace('Comedy Central US','Comedy Central')
                s=s.replace('COMADY CENTRAL','Comedy Central')
                s=s.replace('comady central','Comedy Central')

                s=s.replace('NICKELODEON : UK','Nickleodeon')
                s=s.replace('NICKLEODEON','Nickleodeon')
                s=s.replace('nickleodeon','Nickleodeon')

                s=s.replace('CBBC : UK','CBBC')
                s=s.replace('cbbc','CBBC')

                s=s.replace('CBEEBIES : UK','CBeebies')
                s=s.replace('CBEEBIES','CBeebies')
                s=s.replace('cbeebies','CBeebies')

                s=s.replace('DISNEY CHANNEL : UK','Disney Channel', 1)
                s=s.replace('Disney Channel : UK','Disney Channel', 1)
                #s=s.replace('Disney ','Disney Channel', 1)
                s=s.replace('DISNEY CHANNEL','Disney Channel', 1)
                s=s.replace('disney channel','Disney Channel', 1)
                s=s.replace('DisneyChnl','Disney Channel', 1)
                

                s=s.replace('DISNEY XD : UK','Disney XD', 1)
                s=s.replace('Disney XD : UK','Disney XD', 1)
                s=s.replace('DISNEY XD','Disney XD', 1)
                s=s.replace('disney XD','Disney XD', 1)

                s=s.replace('DISNEY JUNIOR : UK','Disney Junior')
                s=s.replace('Disney Junior : UK','Disney Junior')
                s=s.replace('DISNEY JUNIOR','Disney Junior')
                s=s.replace('DISNEY JUNIOR ','Disney Junior')
                s=s.replace('disney junior','Disney Junior')
                s=s.replace('Disney Jr . UK','Disney Junior')
                s=s.replace('Disney Jr .','Disney Junior')

                s=s.replace('BABY TV : UK','Baby TV')
                s=s.replace('BABY TV','Baby TV')
                s=s.replace('baby tv','Baby TV')

                s=s.replace('NickJr TOO : UK','NickJr')
                s=s.replace('NickJr TOO','NickJr')
                s=s.replace('NICK JR','NickJr')
                s=s.replace('nick jr','NickJr')
                s=s.replace('NickJr :UK','NickJr')

                s=s.replace('ALIBI : UK','Alibi')
                s=s.replace('ALIBI','Alibi')
                s=s.replace('alibi','Alibi')

                s=s.replace('CARTOONIO: UK','Cartoonio')
                s=s.replace('CARTOONIO','Cartoonio')
                s=s.replace('cartoonio','Cartoonio')

                s=s.replace('CARTOON NETWORK: UK','Cartoon Network')
                s=s.replace('CARTOON NETWORK','Cartoon Network')
                s=s.replace('cartoon network','Cartoon Network')

                s=s.replace('CITV : UK','CITV')
                s=s.replace('citv','CITV')

                s=s.replace('BOOMERANG','Boomerang')
                s=s.replace('boomerang','Boomerang')

                s=s.replace('4MUSIC: UK','4Music')
                s=s.replace('4MUSIC','4Music')
                s=s.replace('4music','4Music')

                s=s.replace('MTV MUSIC: UK','MTV MUSIC')
                s=s.replace('MTV MUSIC','MTV MUSIC')

                s=s.replace('VH1: UK','VH1')
                s=s.replace('VH1','VH1')
                s=s.replace('vh1','VH1')

                s=s.replace('FLAVA: UK','Flava')
                s=s.replace('FLAVA','Flava')
                s=s.replace('flava : UK','Flava')


                s=s.replace('KERRANG! TV','Kerrang')
                s=s.replace('kerrang! tv','Kerrang')
                s=s.replace('kerrang','Kerrang')

                s=s.replace('KISS TV: UK','Kiss')
                s=s.replace('KISS TV','Kiss')
                s=s.replace('KISS','Kiss')
                s=s.replace('kiss tv','Kiss')
                s=s.replace('kiss','Kiss')

                s=s.replace('KIX: UK','Kix')
                s=s.replace('KIX','Kix')
                s=s.replace('kix','Kix')

                s=s.replace('SKY PREMIERE : UK','Sky Premiere')
                s=s.replace('SKY PREMIERE','Sky Premiere')
                s=s.replace('Sky Permiere : UK','Sky Premiere')
                s=s.replace('sky permiere','Sky Premiere')
                s=s.replace('Sky Movies Premier','Sky Premiere')
                s=s.replace('SKY MOVIES PREMIERE','Sky Premiere')
                s=s.replace('Sky Premiere Movies','Sky Premiere')
                
                
                s=s.replace('SKY DISNEY : UK','Sky Disney')
                s=s.replace('Sky Disney : UK','Sky Disney')
                s=s.replace('SKY DISNEY','Sky Disney')
                s=s.replace('sky disney','Sky Disney')
                s=s.replace('Sky Movies Disney','Sky Disney')
                s=s.replace('SKY MOVIES DISNEY','Sky Disney')

                s=s.replace('SKY FAMILY HD : UK','Sky Family')
                s=s.replace('SKY FAMILY','Sky Family')
                s=s.replace('Sky Family Movies','Sky Family') 

                s=s.replace('SKY GREATS : UK','Sky Modern Greats')
                s=s.replace('SKY GREATS','Sky Modern Greats')
                s=s.replace('Sky Greats Movies','Sky Modern Greats')
                
                
                s=s.replace('SKY ACTION : UK','Sky Action')
                s=s.replace('Sky Action : UK','Sky Action')
                s=s.replace('SKY ACTION','Sky Action')
                s=s.replace('sky action','Sky Action')
                s=s.replace('Sky Movies Action','Sky Action')
                s=s.replace('SKY MOVIES ACTION','Sky Action')
                s=s.replace('Sky Movies Action & Adventure','Sky Action')
                s=s.replace('Sky Action Movies','Sky Action')
                

                s=s.replace('SKY COMEDY : UK','Sky Comedy')
                s=s.replace('SKY COMEDY','Sky Comedy')
                s=s.replace('sky comedy','Sky comedy')
                s=s.replace('Sky Comedy : UK','Sky comedy')
                s=s.replace('Sky Movies Comedy','Sky Comedy')
                s=s.replace('SKY MOVIES COMEDY','Sky Comedy')
                s=s.replace('Sky Comedy Movies','Sky Comedy')
                

                s=s.replace('SKY THRILLER : UK','Sky Thriller')
                s=s.replace('SKY THRILLER','Sky Thriller')
                s=s.replace('sky thriller','Sky Thriller')
                s=s.replace('Sky Thriller : Uk','Sky Thriller')
                s=s.replace('Sky Movies Thriller','Sky Thriller')
                s=s.replace('Sky Movies Crime & T','Sky Thriller')
                s=s.replace('SKY MOVIES THRILLER','Sky Thriller')
                s=s.replace('Sky Greats Movies','Sky Thriller')
                
                
                s=s.replace('SKY Drama AND ROMANCE : UK','Sky Drama')
                s=s.replace('SKY DRAMA AND ROMANCE','Sky Drama')
                s=s.replace('SKY Drama AND ROMANCE','Sky Drama')
                s=s.replace('Sky Drama : UK','Sky Drama')
                s=s.replace('Sky Movies Drama','Sky Drama')
                s=s.replace('SKY MOVIES DRAMA','Sky Drama')
                s=s.replace('Sky Movies Drama & Romance ','Sky Drama')
                s=s.replace('Sky DramaRom Movies','Sky Drama')
                

                s=s.replace('SKY SCI-FI HORROR : UK','Sky Horror')
                s=s.replace('SKY SCI-FI HORROR','Sky Horror')
                s=s.replace('sky sci-fi & horror','Sky Horror')
                s=s.replace('Sky sci-fi & horror : UK','Sky Horror')
                s=s.replace('Sky Movies Scifi','Sky Horror')
                s=s.replace('SKY MOVIES SCIFI','Sky Horror')
                s=s.replace('Sky ScFiHorror Movies','Sky Horror')          
                

                s=s.replace('SKY SHOWCASE : UK','Sky Showcase')
                s=s.replace('sky showcase : UK','Sky Showcase')
                s=s.replace('SKY SHOWCASE','Sky Showcase')
                s=s.replace('sky showcase','Sky Showcase')
                s=s.replace('Sky Movies Showcase','Sky Showcase')
                s=s.replace('SKY MOVIES SHOWCASE','Sky Showcase')

                s=s.replace('SKY SELECT : UK','Sky Select')
                s=s.replace('sky Select : UK','Sky Select')
                s=s.replace('SKY SELECT','Sky Select')
                s=s.replace('sky select','Sky Select')
                s=s.replace('Sky Movies Select','Sky Select')
                s=s.replace('SKY MOVIES SELECT','Sky Select')
                s=s.replace('Sky Select Movies','Sky Select')
                

                s=s.replace('TRUE MOVIES 1: UK','True Movies')
                s=s.replace('TRUE MOVIES 1','True Movies')
                s=s.replace('true movies 1','True Movies')


                s=s.replace('TRUE MOVIES 2: UK','True Movies 2')
                s=s.replace('TRUE MOVIES 2','True Movies 2')
                s=s.replace('true movies 2','True Movies 2')

                s=s.replace('MOVIES 24 : UK','Movies 24')
                s=s.replace('MOVIES 24','Movies 24')
                s=s.replace('movies 24','Movies 24')


                s=s.replace('MOVIES4MEN : UK','Movies4Men')
                s=s.replace('MOVIES4MEN','Movies4Men')
                s=s.replace('movies4men','Movies4Men')

                s=s.replace('UK : FILM 4','Film4')
                s=s.replace('UK : Film 4','Film4')
                s=s.replace('FILM 4','Film4')
                s=s.replace('film4','Film4')

                s=s.replace('UK : TCM','TCM')
                s=s.replace('TCM : UK','TCM')
                s=s.replace('tcm','TCM')
                s=s.replace('TCM UK','TCM')

                s=s.replace('CineMAX : UK','CineMAX EAST')
                s=s.replace('CineMAX','CineMAX EAST')
                s=s.replace('cinemax','CineMAX EAST')
                s=s.replace('CINEMAX','CineMAX EAST')

                s=s.replace('CineMAX (pacific)','CineMAX WEST')
                s=s.replace('CINEMAX PACIFIC','CineMAX WEST')
                s=s.replace('CINEMAX WEST','Cinemax WEST')
                s=s.replace('cinimax west','Cinimax WEST')


                s=s.replace('AcionMAX: UK','ActionMAX')
                s=s.replace('ActionMAX','ActionMAX')
                s=s.replace('ActnMAXHD','ActionMAX')
                s=s.replace('ActnMAX','ActionMAX')
                s=s.replace('ACTIONMAX','ActionMAX')
                s=s.replace('actionmax','ActionMAX')

                s=s.replace('ThrillerMAX : UK','ThrillerMAX')
                s=s.replace('ThrillerMAX','ThrillerMAX')
                s=s.replace('THRILLERMAX','ThrillerMAX')
                s=s.replace('Thrillermax','ThrillerMAX')
                s=s.replace('thrillermax','ThrillerMAX')

                s=s.replace('SHOWTIME : US','Showtime')
                s=s.replace('SHOWTIME  HD : US','Showtime')
                s=s.replace('SHOWTIME','Showtime')
                s=s.replace('ShowTime HD','Showtime')
                s=s.replace('Showtime HD : US','Showtime')

                s=s.replace('SHOWTIME (PACIFIC)','Showtime West')
                s=s.replace('SHOWTIME WEST','Showtime West')
                s=s.replace('showtime west','Showtime West')

                s=s.replace('SHOWTIME SHOWCASE','Showtime Showcase')
                s=s.replace('showtime showcase','Showtime Showcase')


                s=s.replace('SHOWTIME EXTREME','Showtime Extreme')
                s=s.replace('showtime extreme','Showtime Extreme')

                s=s.replace('SHOWTIME BEYOND','Showtime Beyond')
                s=s.replace('showtime beyond','Showtime Beyond')

                s=s.replace('SHOWTIME NEXT : US','Showtime Next')
                s=s.replace('SHOWTIME NEXT','Showtime Next')
                s=s.replace('showtime next','Showtime Next')

                s=s.replace('THE MOVIE CHANNEL','The Movie Channel')
                s=s.replace('the movie chanel','The Movie Channel')

                s=s.replace('THE MOVIE CHANNEL EXTRA','The Movie Channel Extra')
                s=s.replace('the movie chanel extra','The Movie Channel Extra')

                s=s.replace('ENCORE : UK','Encore')
                s=s.replace('ENCORE','Encore')
                s=s.replace('encore','Encore')

                s=s.replace('STARZ HD : US','Starz')
                s=s.replace('STARZ','Starz')
                s=s.replace('starz','Starz')

                s=s.replace('STARZ (pacific)','Starz East', 1)
                s=s.replace('STARZ WEST','Starz East', 1)
                s=s.replace('starz west','Starz East', 1)

                s=s.replace('STARZ EDGE : US','Starz Edge East', 1)
                s=s.replace('STARZ EDGE','Starz Edge East', 1)
                s=s.replace('starz edge','Starz Edge East', 1)
                s=s.replace('Starz Edge','Starz Edge East', 1)
                s=s.replace('StrzEdgeHD','Starz Edge East', 1)

                s=s.replace('StrzKidsHD','Starz Kids Family East', 1)
                s=s.replace('StrzKids','Starz Kids Family East', 1)



                s=s.replace('STARZ Cinema : US','Starz Cinema East', 1)
                s=s.replace('STARZ CINEMA','Starz Cinema East', 1)
                s=s.replace('starz cinema','Starz Cinema East', 1)
                s=s.replace('Starz Cinema','Starz Cinema East',1)
                s=s.replace('StrzCinmHD','Starz Cinema East', 1)
                s=s.replace('StrzCinm','Starz Cinema East', 1)

                 
                s=s.replace('STARZ COMEDY : US','Starz Comedy East', 1)
                s=s.replace('STARZ COMEDY','Starz Comedy East', 1)
                s=s.replace('starz comedy','Starz Comedy East', 1)
                s=s.replace('Starz Comedy','Starz Comedy East', 1)
                s=s.replace('StrzComedy','Starz Comedy East', 1)


                s=s.replace('STARZ IN BLACK : US','Starz In Black East', 1)
                s=s.replace('STARZ IN BLACK','Starz In Black East', 1)
                s=s.replace('starz in black','Starz In Black East', 1)
                s=s.replace('Starz In Black','Starz In Black East', 1)
                s=s.replace('StrzBlack','Starz In Black East', 1)
                
                s=s.replace('STARZ HD : US','Starz', 1)
                s=s.replace('STARZ','Starz', 1)
                s=s.replace('starz','Starz', 1)
                s=s.replace('Starz HD','Starz', 1)

                s=s.replace('SONY MOVIE CHANNEL','Sony Movie Channel')
                s=s.replace('sony movie channel','Sony Movie Channel')

                s=s.replace('SKY SPORTS NEWS : UK','Sky Spts News')
                s=s.replace('SKY SPORTS NEWS','Sky Spts News')
                s=s.replace('sky sports news','Sky Spts News')
                s=s.replace('[COLOR white]Sky Sports News[/COLOR]','Sky Spts News')

                s=s.replace('SKY SPORTS 1 : UK','Sky Sports 1')
                s=s.replace('SKY SPORTS 1 HD','Sky Sports 1')
                s=s.replace('SKY SPORTS 1','Sky Sports 1')
                s=s.replace('SKYSPORTS 1','Sky Sports 1')
                s=s.replace('Sky Sports 1 HD','Sky Sports 1')
                s=s.replace('sky sports 1s','Sky Sports 1')
                s=s.replace('Sky Sports 1 HD+','Sky Sports 1')

                s=s.replace('SKY SPORTS 2 : UK','Sky Sports 2')
                s=s.replace('SKY SPORTS 2 HD','Sky Sports 2')
                s=s.replace('SKY SPORTS 2','Sky Sports 2')
                s=s.replace('SKYSPORTS 2','Sky Sports 2')
                s=s.replace('sky sports 2s','Sky Sports 2')
                s=s.replace('Sky Sports 2 HD+','Sky Sports 2')
                s=s.replace('Sky Sports 2 HD','Sky Sports 2')

                s=s.replace('SKY SPORTS 3 : UK','Sky Sports 3')
                s=s.replace('SKY SPORTS 3 HD','Sky Sports 3')
                s=s.replace('SKY SPORTS 3','Sky Sports 3')
                s=s.replace('SKYSPORTS 3','Sky Sports 3')
                s=s.replace('sky sports 3s','Sky Sports 3')
                s=s.replace('Sky Sports 3 HD+','Sky Sports 3')
                s=s.replace('Sky Sports 3 HD3','Sky Sports 3')


                s=s.replace('SKY SPORTS 4 : UK','Sky Sports 4')
                s=s.replace('SKY SPORTS 4 HD','Sky Sports 4')
                s=s.replace('SKY SPORTS 4','Sky Sports 4')
                s=s.replace('SKYSPORTS 4','Sky Sports 4')
                s=s.replace('sky sports 4s','Sky Sports 4')
                s=s.replace('Sky Sports 4 HD+','Sky Sports 4')
                s=s.replace('Sky Sports 4 HD','Sky Sports 4')


                s=s.replace('SKY SPORTS 5 : UK','Sky Sports 5')
                s=s.replace('SKY SPORTS 5 HD','Sky Sports 5')
                s=s.replace('SKY SPORTS 5','Sky Sports 5')
                s=s.replace('SKYSPORTS 5','Sky Sports 5')
                s=s.replace('sky sports 5s','Sky Sports 5')
                s=s.replace('Sky Sports 5 HD+','Sky Sports 5')
                s=s.replace('Sky Sports 5 HD','Sky Sports 5')

                s=s.replace('SKY SPORTS F1 : UK','Sky Sports F1')
                s=s.replace('SKY SPORTS F1 HD','Sky Sports F1')
                s=s.replace('SKY SPORTS F1','Sky Sports F1')
                s=s.replace('Sky Sports F1/DARTS','Sky Sports F1')
                s=s.replace('Sky Sports F1 HD+','Sky Sports F1')
                s=s.replace('sky sports F1 HD','Sky Sports F1')
                s=s.replace('Sky Spts F1','Sky Sports F1')

                s=s.replace('BT SPORT 1 HDS : UK','BT Sport 1')
                s=s.replace('BT Sport 1 HD','BT Sport 1')
                s=s.replace('BT Sport 1','BT Sport 1')
                s=s.replace('BT Sport 1HD','BT Sport 1')
                s=s.replace('BT SPORT 1 ','BT Sport 1')
                s=s.replace('BT SPORT 1','BT Sport 1')
                s=s.replace('BT sport 1 HD','BT Sport 1')

                s=s.replace('BT SPORT 2 HDS : UK','BT Sport 2')
                s=s.replace('BT Sport 2 HD','BT Sport 2')
                s=s.replace('BT SPORT 2','BT Sport 2')
                s=s.replace('bt sport 2','BT Sport 2')
                s=s.replace('BT sport 2 HD','BT Sport 2')

                s=s.replace('BT SPORT EUROPE HDS : UK','BT Sport Europe')
                s=s.replace('BT Sport EUROPE HD','BT Sport Europe')
                s=s.replace('BT Sport EUROPE','BT Sport Europe')
                s=s.replace('BT SPORT EUROPE','BT Sport Europe')
                s=s.replace('BT Sport Europe HD','BT Sport Europe')
                s=s.replace('BT sport europe HD','BT Sport Europe')

                s=s.replace('GOLF HD : US','The Golf Channel')
                s=s.replace('GOLF','The Golf Channel')
                s=s.replace('golf','The Golf Chhanel')
                s=s.replace('THE GOLF CHANNEL : US','The Golf Channel')
                s=s.replace('THE GOLF CHANNEL','The Golf Channel')
                s=s.replace('The Golf Channel','The Golf Channel')

                s=s.replace('SETANTA IRELAND HDS : UK','Setana Ireland')
                s=s.replace('SETANTA IRELAND HD','Setanta Ireland')
                s=s.replace('setanta ireland','Setanta Ireland')
                s=s.replace('Setanta Ireland HD','Setanta Ireland')

                s=s.replace('SETANTA IRELAND HDS : UK','Setanta Ireland')
                s=s.replace('SETANTA IRELAND HD','Setanta Ireland')
                s=s.replace('SETANTA IRELAND','Setanta Ireland')
                s=s.replace('setanta ireland','Setanta Ireland')
                s=s.replace('Setanta Ireland HD','Setanta Ireland')

                s=s.replace('SETANTA SPORTS 1 HDS : UK','Setanta Sports 1')
                s=s.replace('SETANTA SPORTS 1 HD','Setanta Sports 1')
                s=s.replace('SETANTA SPORTS 1','Setanta Sports 1')
                s=s.replace('setanta sports 1','Setanta Sports 1')
                s=s.replace('setanta sports','Setanta Sports 1')
                s=s.replace('Setanta Sports 1 HD','Setanta Sports 1')

                s=s.replace('AT THE RACES HD','At The Races')
                s=s.replace('AT THE RACES : UK','At The Races')
                s=s.replace('AT THE RACES','At The Races')
                s=s.replace('at the races','At The Races')
                s=s.replace('At The RacesS : UK',' At The Races')

                s=s.replace('RACING UK HDS : UK','Racing UK')
                s=s.replace('RACING HD','Racing UK')
                s=s.replace('RACING UK','Racing UK')
                s=s.replace('racing uk','Racing UK')
                s=s.replace('RACING UK','Racing UK')

                s=s.replace('SETANTA IRELAND HDS : UK','Setanta Ireland')
                s=s.replace('SETANTA IRELAND : UK','Setana Ireland')
                s=s.replace('SETANTA IRELAND HD','Setanta Ireland')
                s=s.replace('SETANTA IRELAND','Setanta Ireland')
                s=s.replace('setanta ireland','Setanta Ireland')
                s=s.replace('Setanta Sports Ireland','Setanta Ireland')

                s=s.replace('EUROSPORT : UK','Eurosport')
                s=s.replace('BRITISH EUROPORT 1','EuroSport')
                s=s.replace('BRITISH EUROSPORT 1 HD','Eurosport')
                s=s.replace('British Eurosport 1','Eurosport')
                s=s.replace('EUROSPORT HD','Eurosport')
                s=s.replace('EUROSPORT','Eurosport')
                s=s.replace('EurosportS 1','Eurosport')
                               
                s=s.replace('EUROSPORT 2 : UK','Eurosport 2')
                s=s.replace('EurosportS 2','Eurosport 2')
                s=s.replace('BRITISH EUROPORT 2','EuroSport 2')
                s=s.replace('BRITISH EUROSPORT 2 HD','Eurosport 2')
                s=s.replace('British Eurosport 2','Eurosport 2')
                s=s.replace('EUROSPORT 2','Eurosport 2')
                s=s.replace('EUROSPORT 2 HD','Eurosport 2')

                s=s.replace('MOTORS TV : UK','Motors TV')
                s=s.replace('MOTORS TV','Motors TV')
                s=s.replace('motors tv','Motots TV')

                s=s.replace('NBC SPORTS NETWORK : US','NBCSN')
                s=s.replace('NBC SPORTS NETWORK','NBCSN')
                s=s.replace('nbcsn','NBCSN')
                s=s.replace('Nbc Sports Network','NBCSN')

                s=s.replace('MUTV: UK','MUTV')
                s=s.replace('MUTV','MUTV')
                s=s.replace('mutv','MUTV')

                s=s.replace('CHELSEA : UK','Chelsea TV')
                s=s.replace('CHELSEA TV','Chelsea TV')
                s=s.replace('CHELSEA','Chelsea TV')
                s=s.replace('Chelsea TV : UK','Chelsea TV')

                s=s.replace('LFCTV : UK','Lfctv')
                s=s.replace('LFCTV ','Lfctv')
                s=s.replace('Liverpool FC TV','Lfctv')
                s=s.replace('liverpool TV','Lfctv')

                s=s.replace('ASTRO SUPERSPORT 1 : INT','Astro SuperSport')
                s=s.replace('ASTRO SUPERSPORT 1','Astro SuperSport')
                s=s.replace('Astro super Sport 1','Astro SuperSport ')

                s=s.replace('ASTRO SUPERSPORT 2 : INT','Astro SuperSport 2')
                s=s.replace('ASTRO SUPERSPORT 2','Astro SuperSport 2')

                s=s.replace('Astro super Sport 2','Astro SuperSport 2')

                s=s.replace('ASTRO SUPERSPORT 3 : INT','Astro SuperSport 3')
                s=s.replace('ASTRO SUPERSPORT 3','Astro SuperSport 3')
                s=s.replace('Astro super Sport 3','Astro SuperSport 3')

                s=s.replace('ARENA SPORTS 1 : INT','Arenasport 1')
                s=s.replace('ARENA SPORTS 1','Arenasport 1')
                s=s.replace('Arena Sport 1','Arenasport 1')

                s=s.replace('ARENA SPORTS 2 : INT','Arenasport 2')
                s=s.replace('ARENA SPORTS 2','Arenasport 2')
                s=s.replace('Arena Sport 2','Arenasport 2')

                s=s.replace('ARENA SPORTS 3 : INT','Arenasport 3')
                s=s.replace('ARENA SPORTS 3','Arenasport 3')
                s=s.replace('Arena Sport 3','Arenasport 3')


                s=s.replace('ARENA SPORTS 4 : INT','Arenasport 4')
                s=s.replace('ARENA SPORTS 4','Arenasport 4')
                s=s.replace('Arena Sport 4','Arenasport 4')

                s=s.replace('BIG TEN NETWORK','Big Ten Network')
                s=s.replace('big ten network','Big Ten Network')

                s=s.replace('ULTIMATE EVENT SPORTS','Ultimate Event Sports')
                s=s.replace('ultimate event sports','Ultimate Even Sports')

                s=s.replace('ESPN : US','ESPN')
                s=s.replace('espn','ESPN')
                s=s.replace('ESPN LA','ESPN')


                s=s.replace('BOXNATION HDS : UK','Box Nation')
                s=s.replace('Box Nation : UK','Box Nation')
                s=s.replace('BOXNATION','Box Nation')

                s=s.replace('ESPN 2 HD : US','ESPN2')
                s=s.replace('espn 2','ESPN2')
                s=s.replace('ESPN 2','ESPN2')
                s=s.replace('ESPN 2 LA','ESPN2')

                s=s.replace('TSN 1 : US','TSN 1')
                s=s.replace('TSN 1 HD','TSN 1')
                s=s.replace('TSN1','TSN 1')

                s=s.replace('TSN 2 : US','TSN 2')
                s=s.replace('TSN 2 HD','TSN 2')
                s=s.replace('TSN2','TSN 2')

                s=s.replace('TSN 3 : US','TSN 3')
                s=s.replace('TSN 3 HD','TSN 3')
                s=s.replace('TSN3','TSN 3')

                s=s.replace('TSN 4 : US','TSN 4')
                s=s.replace('TSN 4 HD','TSN 4')
                s=s.replace('TSN4','TSN 4')

                s=s.replace('TSN 5 : US','TSN 5')
                s=s.replace('TSN  5 HD','TSN 5')
                s=s.replace('TSN5','TSN 5')

                s=s.replace('fox SPORTS 1 : US','Fox Sports 1')
                s=s.replace('fox SPORTS 1','Fox Sports 1')
                s=s.replace('fox sports 1','Fox Sports 1')
                s=s.replace('FOX SPORTS 1 HD','Fox Sports 1')

                s=s.replace('fox SPORTS 2 : US','Fox Sports 2')
                s=s.replace('fox SPORTS 2','Fox Sports 2')
                s=s.replace('FOX SPORTS 2 HD','Fox Sports 2')
                s=s.replace('fox sports 2','Fox Sports 2')

                s=s.replace('MLB NETWORK','MLB Network')

                s=s.replace('NHL NETWORK : US','NHL Network USA')
                s=s.replace('NHL NETWORK','NHL Network USA')

                s=s.replace('NFL NETWORK : US','NFL Network')
                s=s.replace('NFL NETWORK','NFL Network')

                s=s.replace('PREMIER SPORTS : UK','Premier Sports HD')
                s=s.replace('PREMIER SPORTS','Premier Sports HD')

                s=s.replace('WWE NETWORK HD : US','WWE NETWORK HD')
                s=s.replace('WWE NETWORK','WWE NETWORK HD')
                s=s.replace('wwe network','WWE NETWORK HD')
                s=s.replace('WWE NETWORK HD - USA LINK','WWE NETWORK HD')

                s=s.replace('SPORTS NET WORLD','Sports Net World HD')

                s=s.replace('SPORTSNET ONE : US','Sports Net One')
                s=s.replace('SPORTSNET ONE','Sports Net One')

                s=s.replace('SPORTS NET Ontario','Sports Net Ontario')

                s=s.replace('THE SCORE','SportsNet 360 HD')

                s=s.replace('SPORTS NET WORLD','Sports Net World HD')

                s=s.replace('CBS SPORTS : US','CBS Sports Network')

                s=s.replace('CBS SPORTS','CBS Sports Network')

                s=s.replace('CTH STADIUM 1 : INT','CTH Stadium 1')
                s=s.replace('CTH STADIUM 1 HD','CTH Stadium 1')
                s=s.replace('CTH STADIUM 1','CTH Stadium 1')
                s=s.replace('SPORTS: CTH STADIUM 1 HD','CTH Stadium 1')
                s=s.replace('CTH Stadium 1 : INT','CTH Stadium 1')

                s=s.replace('CTH STADIUM 2 : INT','CTH Stadium 2')
                s=s.replace('SPORTS: CTH STADIUM 2 HD','CTH Stadium 2')
                s=s.replace('CTH STADIUM 2','CTH Stadium 2')
                s=s.replace('CTH STADIUM 2 HD','CTH Stadium 2')
                s=s.replace('CTH Stadium 2 : INT','CTH Stadium 2')

                s=s.replace('CTH STADIUM 3 : INT','CTH Stadium 3')
                s=s.replace('SPORTS: CTH STADIUM 3 HD','CTH Stadium 3')
                s=s.replace('CTH STADIUM 3','CTH Stadium 3')
                s=s.replace('CTH STADIUM 3 HD','CTH Stadium 3')
                s=s.replace('CTH Stadium 3 : INT','CTH Stadium 3')

                s=s.replace('CTH Stadium 4 : INT','CTH Stadium 4')
                s=s.replace('SPORTS: CTH STADIUM 4 HD','CTH Stadium 4')
                s=s.replace('CTH STADIUM 4 HD','CTH Stadium 4')
                s=s.replace('CTH STADIUM 4','CTH Stadium 4')
                s=s.replace('CTH STADIUM 4 : INT','CTH Stadium 4')

                s=s.replace('CTH STADIUM 5 : INT','CTH Stadium 5')
                s=s.replace('CTH STADIUM 5','CTH Stadium 5')
                s=s.replace('SPORTS: CTH STADIUM 5 HD','CTH Stadium 5')
                s=s.replace('CTH STADIUM 5 HD','CTH Stadium 5')
                s=s.replace('CTH Stadium 5 : INT','CTH Stadium 5')

                s=s.replace('CTH Stadium 6 : INT','CTH Stadium 6')
                s=s.replace('CTH STADIUM 6','CTH Stadium 6')
                s=s.replace('SPORTS: CTH STADIUM 6 HD','CTH Stadium 6')
                s=s.replace('CTH STADIUM 6 : INT','CTH Stadium 6')
                s=s.replace('CTH STADIUM 6 HD','CTH Stadium 6')

                s=s.replace('CTH Stadium X : INT','CTH Stadium X')
                s=s.replace('CTH STADIUM X','CTH Stadium X')
                s=s.replace('SPORTS: CTH STADIUM X HD','CTH Stadium X')
                s=s.replace('CTH STADIUM X : INT','CTH Stadium X')
                s=s.replace('CTH STADIUM X HD','CTH Stadium X')

                s=s.replace('BEIN SPORTS 10 : INT','bein-sports-10hd')
                s=s.replace('BEIN SPORTS 10 HD : INT','bein-sports-10hd')
                s=s.replace('bein-sports-10hd : INT','bein-sports-10hd')
                s=s.replace('BEIN SPORTS 10 HD','bein-sports-10hd')
                s=s.replace('BEIN SPORTS 10','bein-sports-10hd')
                s=s.replace('BeinSports 10','bein-sports-10hd')
                s=s.replace('Bein Sports 10','bein-sports-10hd')


                s=s.replace('BEIN SPORTS 11 : INT','bein-sports-11hd')
                s=s.replace('BEIN SPORTS 11 HD : INT','bein-sports-11d')
                s=s.replace('bein-sports-11hd : INT','bein-sports-11hd')
                s=s.replace('BEIN SPORTS 11 HD','bein-sports-11hd')
                s=s.replace('BEIN SPORTS 11','bein-sports-11hd')
                s=s.replace('BeinSports 11','bein-sports-11hd')
                s=s.replace('Bein Sports 11','bein-sports-11hd')

                s=s.replace('BEIN SPORTS 12 : INT','bein-sports-12hd')
                s=s.replace('BEIN SPORTS 12 HD : INT','bein-sports-12hd')
                s=s.replace('bein-sports-12hd : INT','bein-sports-12hd')
                s=s.replace('BEIN SPORTS 12 HD','bein-sports-12hd')
                s=s.replace('BEIN SPORTS 12','bein-sports-12hd')
                s=s.replace('BeinSports 12','bein-sports-12hd')
                s=s.replace('Bein Sports 12','bein-sports-12hd')

                s=s.replace('BEIN SPORTS 13 : INT','bein-sports-13hd')
                s=s.replace('BEIN SPORTS 13 HD','bein-sports-13hd')
                s=s.replace('BEIN SPORTS 13','bein-sports-13hd')
                s=s.replace('BeinSports 13','bein-sports-13hd')


                s=s.replace('BEIN SPORTS 14 : INT','bein-sports-14hd')
                s=s.replace('BEIN SPORTS 14 HD','bein-sports-14hd')
                s=s.replace('BeinSports 14','bein-sports-14hd')

                s=s.replace('BEIN SPORTS 15 : INT','bein-sports-15hd')
                s=s.replace('BEIN SPORTS 15 HD','bein-sports-15hd')
                s=s.replace('BeinSports 15','bein-sports-15hd')

                s=s.replace('BEIN SPORTS 16 : INT','bein-sports-16hd')
                s=s.replace('BEIN SPORTS 16 HD','bein-sports-16hd')
                s=s.replace('BeinSports 16','bein-sports-16hd')


                s=s.replace('BEIN SPORTS 1 : INT','bein-sports-1hd')
                s=s.replace('BEINS1','bein-sports-1hd')
                s=s.replace('BEIN SPORTS 1 HD','bein-sports-1hd')
                s=s.replace('BEIN SPORTS 1','bein-sports-1hd')
                s=s.replace('BeinSports 1','bein-sports-1hd')
                s=s.replace('Bein Sports 1','bein-sports-1hd')

                s=s.replace('BEIN SPORTS 2 : INT','bein-sports-2hd')
                s=s.replace('BEIN SPORTS 2 HD','bein-sports-2hd')
                s=s.replace('BEIN SPORTS 2','bein-sports-2hd')
                s=s.replace('BeinSports 2','bein-sports-2hd')
                s=s.replace('Bein Sports 2','bein-sports-2hd')

                s=s.replace('BEIN SPORTS 3 : INT','bein-sports-3hd')
                s=s.replace('BEIN SPORTS 3 HD','bein-sports-3hd')
                s=s.replace('BEIN SPORTS 3','bein-sports-3hd')
                s=s.replace('BeinSports 2','bein-sports-2hd')
                s=s.replace('Bein Sports 2','bein-sports-2hd')


                s=s.replace('BEIN SPORTS 4 : INT','bein-sports-4hd')
                s=s.replace('BEIN SPORTS 4 HD','bein-sports-4hd')
                s=s.replace('BEIN SPORTS 4','bein-sports-4hd')
                s=s.replace('BeinSports 4','bein-sports-4hd')
                s=s.replace('Bein Sports 4','bein-sports-4hd')


                s=s.replace('BEIN SPORTS 5 : INT','bein-sports-5hd')
                s=s.replace('BEIN SPORTS 5 HD','bein-sports-5hd')
                s=s.replace('BEIN SPORTS 5','bein-sports-5hd')
                s=s.replace('BeinSports 5','bein-sports-6hd')
                s=s.replace('Bein Sports 5','bein-sports-6hd')

                s=s.replace('BEIN SPORTS 6 : INT','bein-sports-6hd')
                s=s.replace('BEIN SPORTS 6 HD','bein-sports-6hd')
                s=s.replace('BEIN SPORTS 6','bein-sports-6hd')
                s=s.replace('BeinSports 6','bein-sports-6hd')
                s=s.replace('Bein Sports 6','bein-sports-6hd')

                s=s.replace('BEIN SPORTS 7 : INT','bein-sports-7hd')
                s=s.replace('BEIN SPORTS 7 HD','bein-sports-7hd')
                s=s.replace('BEIN SPORTS 7','bein-sports-7hd')
                s=s.replace('BeinSports 7','bein-sports-7hd')
                s=s.replace('Bein Sports 7','bein-sports-7hd')

                s=s.replace('BEIN SPORTS 8 : INT','bein-sports-8hd')
                s=s.replace('BEIN SPORTS 8 HD','bein-sports-8hd')
                s=s.replace('BEIN SPORTS 8','bein-sports-8hd')
                s=s.replace('BeinSports 8','bein-sports-8hd')
                s=s.replace('Bein Sports 8','bein-sports-8hd')

                s=s.replace('BEIN SPORTS 9 : INT','bein-sports-9hd')
                s=s.replace('BEIN SPORTS 9 HD : INT','bein-sports-9hd')
                s=s.replace('bein-sports-9hd : INT ','bein-sports-9hd')
                s=s.replace('BEIN SPORTS 9 HD','bein-sports-9hd')
                s=s.replace('BEIN SPORTS 9','bein-sports-9hd')
                s=s.replace('BeinSports 9','bein-sports-9hd')
                s=s.replace('Bein Sports 9','bein-sports-9hd')

                s=s.replace('BEIN SPORTS : INT','bein-sports')
                s=s.replace('BEIN SPORTS HD','bein-sports')
                s=s.replace('BEIN SPORTS','bein-sports')

                s=s.replace('BEIN SPORTS NEWS : INT','bein-sports-news')
                s=s.replace('BEIN SPORTS NEWS HD','bein-sports-news')
                s=s.replace('BEIN SPORTS NEWS','bein-sports-news')

                s=s.replace('BIEN SPORTS 1 HD','Bein-sports-1hd')

                s=s.replace('CNN HD','CNN US')
                s=s.replace('CNN','CNN US')

                s=s.replace('CNN INTERNATIONAL','CNN')

                s=s.replace('BLOOMBERG TV','Bloomberg')

                s=s.replace('AMC : US','AMC')
                s=s.replace('AMC HD from BT','AMC')

                s=s.replace('FOX AMERICA','FOX News')
                s=s.replace('FOX NEWS','FOX News')

                s=s.replace('EURO NEWS','Euro News')

                s=s.replace('FOX AMERICA','FOX News')

                s=s.replace('BBC WORLD NEWS','BBC World News')
                 
                s=s.replace('BBC NEWS','BBC News')

                s=s.replace('CNBC : US','CNBC')

                s=s.replace('MSNBC HD','MSNBC')

                s=s.replace('SKY NEWS','Sky News')
                s=s.replace('Sky News : UK','Sky News')

                s=s.replace('A AND E : US','A and E')
                s=s.replace('A AND E','A and E')
                s=s.replace('A&amp;E','A and E')

                s=s.replace('H2 USA','H2USA ')
                s=s.replace('HISTORY2 (H2) HD : US','H2USA')
                s=s.replace('HISTORY : US','H2USA')

                s=s.replace('HBO SIGNATURE : US','HBO Signature')
                s=s.replace('HBO SIGNATURE','HBO Signature')
                s=s.replace('HBO EastSignature','HBO Signature')

                s=s.replace('HBO 1 : US','HBO East')
                s=s.replace('HBO 1','HBO East')
                s=s.replace('HBO EAST : US ','HBO East')
                s=s.replace('HBO EAST1','HBO East')
                s=s.replace('HBO EAST1 : US','HBO East')
                s=s.replace('HBO eastEAST : US','HBO East')
                s=s.replace('HBO EAST ','HBO East')

                s=s.replace('HBO 2 : US','HBO 2 East')
                s=s.replace('HBO EAST2 : US','HBO East')
                s=s.replace('HBO 2 ','HBO 2 East')

                s=s.replace('HBO COMEDY : US','HBO Comedy East')
                s=s.replace('HBO COMEDY','HBO Comedy East')
                s=s.replace('HBO EastCOMEDY : US','HBO Comedy East')

                s=s.replace('HBOCmdy HD','HBO Comedy East')
                s=s.replace('HBOCmdy','HBO Comedy East')


                s=s.replace('HBOZone HD','HBO Zone')
                s=s.replace('HBOZone','HBO Zone')


                s=s.replace('HBO ZONE : US','HBO Zone')
                s=s.replace('HBO ZONE ','HBO Zone')

                s=s.replace('HALLMARK HD : US','Hallmark Channel')
                s=s.replace('HALLMARK','Hallmark Channel')
                s=s.replace('Hallmark','Hallmark Channel')
                s=s.replace('Hallmark Channel HD : US','Hallmark Channel')

                s=s.replace('Cinemax','CineMAX East')

                s=s.replace('PAC-12 Mountain HD','PAC-12 Mountain')
                s=s.replace('PAC-12 National','PAC-12 National')

                s=s.replace('WGN News C','WGN News')

                s=s.replace('PAC-12 Arizona HD','PAC-12 Arizona')
                s=s.replace('PAC-12 Arizona','PAC-12 Arizona')

                s=s.replace('PAC-12 Bay Area HD','PAC-12 Bay Area')
                s=s.replace('PAC-12 Bay Area','PAC-12 Bay Area')

                s=s.replace('PAC-12 Los Angeles','PAC-12 Los Angeles')

                s=s.replace('PAC-12 Oregon HD','PAC-12 Oregon')

                f=open(favourites,'w')
                f.write(s)
                f.close()
                
              


import favs1
import mail1
import urllib, urllib2, re, os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon 
import mail
import favs



def INDEX():
        addDir("[B]Stream fixes[/B] - [I]Will only add indivdual streams in your epg guide. It wont add moives or 24/7 shows atm[/I]","favsaddon.co.uk",2,"")
        addDir("[B]Send Feed Back[/B] - [I]For streams you favourite and Still didnt intergrate[/I]","favsaddon.co.uk",3,"")
        addDir("[B]Clear Your Favourites[/B] - [I]Remove all favourites and start again[/I]","favsaddon.co.uk",4,"")
        addDir("How To Video","favsaddon.co.uk",5,"")
        
def runfavs():
        favs1.main()
        dialog = xbmcgui.Dialog()
        if dialog.yesno("Eazy-Epg", 'Modify favourites file'):
            if __name__ == '__main__':
                favs.main()
          
                dialog = xbmcgui.Dialog()
                dialog.ok('Eazy-Epg', 'Done Adding Title data to favourites :)')
                path = xbmc.translatePath(os.path.join('special://home/addons/script.eazy.epg',''))
                advance = os.path.join(path,'favs.py')
                a = open(advance,"w")
                a.write('def main():\n    pass')
                a.close()
    
def sendfavourites():
    mail1.main()    
    if __name__ == '__main__':
        mail.main()
            
        dialog = xbmcgui.Dialog()
        dialog.ok('Eazy-Epg','your titles will be intergrated asap thank you')
        path = xbmc.translatePath(os.path.join('special://home/addons/script.eazy.epg',''))
        advance = os.path.join(path,'mail.py')
        a = open(advance,"w")
        a.write('def main():\n    pass')
        a.close()

def deletefavourites():
    dialog = xbmcgui.Dialog()
    dialog.ok('Eazy-Epg', 'Sure you want to delete all your favourites?')
    favourites=xbmc.translatePath('special://profile/favourites.xml')
    os.remove(favourites)
    
def howto():
	print "play how to"
    #addon_handle = int(sys.argv[1])

    #xbmcplugin.setContent(addon_handle, 'movies')

    #url = ''
    #li = xbmcgui.ListItem('coming soon', iconImage='DefaultVideo.png')
    #xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

    #xbmcplugin.endOfDirectory(addon_handle)
    #myplayer = xbmc.Player()
    #myplayer.play('')

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]
                                
    return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass
try:        
	mode = int(params["mode"])
except:
	pass
try:        
	description = urllib.unquote_plus(params["description"])
except:
	pass
	
def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
    
def addDir2(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
    
def addLink(name,url,iconimage,urlType):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('IsPlayable','true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

if mode==None or url==None or len(url)<1:
        print ""
        INDEX()
     
elif mode==2:
        runfavs()
        
elif mode==3:
        sendfavourites()

elif mode==4:
        deletefavourites()
        
elif mode==5:
	    howto()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
def main():
    print 'import mail'
import xbmc 
import urllib, urllib2
import sys,re,os

url = 'http://favsaddon.co.uk/main/mail.py'
path = xbmc.translatePath(os.path.join('special://home/addons/script.eazy.epg',''))
advance = os.path.join(path,'mail.py')
responce = urllib2.urlopen(url)
a = open(advance,"w")
a.write(responce.read())
a.close()
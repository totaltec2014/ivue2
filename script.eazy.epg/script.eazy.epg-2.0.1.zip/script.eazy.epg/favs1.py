def main ():
	print 'import favs'
import xbmc
import urllib, urllib2
import sys,re,os
url = 'http://favsaddon.co.uk/main/favs.py'
path = xbmc.translatePath(os.path.join('special://home/addons/script.eazy.epg',''))
advance = os.path.join(path,'favs.py')
responce = urllib2.urlopen(url)
a = open(advance,"w")
a.write(responce.read())
a.close()
import xbmc
import xbmcaddon 
import os
import urllib
import time
import skins
import streaming

dp = skins.dp
addonid = 'script.ivueguide'
addon = xbmcaddon.Addon(addonid)
path = xbmc.translatePath(os.path.join('special://home', 'addons', 'script.ivueguide', 'resources', 'subs'))
setting = addon.getSetting('last.sub')
try:
    prnum= sys.argv[ 1 ]
except:
    pass

def m3u8():
    if not os.path.exists(path):
        os.makedirs(path)
    fileurl = 'http://ivuetvguide.com/ivueguide/subs/%s.py' % setting
    file = os.path.join(path,"%s.py" % setting) 
    dp.create("iVue","Downloading %s.m3u8 sub" % setting,'')
    urllib.urlretrieve(fileurl,file,lambda nb, bs, fs, url=fileurl: skins._pbhook(nb,bs,fs,fileurl,dp))
    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    xbmc.executebuiltin('XBMC.RunScript(special://home/addons/script.ivueguide/resources/subs/%s.py)' % setting)
    time.sleep(10)     
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )

def ts():
    if not os.path.exists(path):
        os.makedirs(path)
    fileurl = 'http://ivuetvguide.com/ivueguide/subs/%sts.py' % setting
    file = os.path.join(path,"%sts.py" % setting) 
    dp.create("iVue","Downloading %s.ts sub" % setting,'')
    urllib.urlretrieve(fileurl,file,lambda nb, bs, fs, url=fileurl: skins._pbhook(nb,bs,fs,fileurl,dp))
    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    xbmc.executebuiltin('XBMC.RunScript(special://home/addons/script.ivueguide/resources/subs/%sts.py)' % setting)
    time.sleep(10)
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
 
if prnum == 'm3u8':
    m3u8()

elif prnum == 'ts':
    ts() 

4TH Oct 2016

Added function in gui.py to control onfocus epg text and nofocus epg text

Added control in settings to change the colour of both onfocus and nofocus epg text

Added PVRsimpleclient ini creation in Subscriptions settings (Works on other PVR clients that use homerun and OTA dtvb)

Added "Enable offer to choose streams" in gui.py

Added "Enable offer to choose streams in settings" (on or off)



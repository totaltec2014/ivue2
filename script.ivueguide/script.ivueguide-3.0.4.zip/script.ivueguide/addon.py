#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu

#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc,xbmcgui,xbmcaddon,os,time
import urllib
import urllib2
import skins
from shutil import copytree
ADDONID = 'script.ivueguide'
ADDON = xbmcaddon.Addon(ADDONID) 
PACKAGES       = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages'))
skin = ADDON.getSetting('skin')
default = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'skins', 'Default'))
setSkin = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'skins', skin))
SkinFolder = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'skins')) 
skinType = int(ADDON.getSetting('customSkin.type'))
d = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()

if not os.path.exists(default):
    url = 'http://ivuetvguide.com/ivueguide/skins/Default.zip'
    zipfile = os.path.join(PACKAGES,"default.zip") 
    dp.create("iVue","Downloading Default Skin",'')
    urllib.urlretrieve(url,zipfile,lambda nb, bs, fs, url=url: skins._pbhook(nb,bs,fs,url,dp))
    skins.extract(zipfile, SkinFolder)
    time.sleep(1)
    dp.close() 
 
if not os.path.exists(setSkin):
    url = 'http://ivuetvguide.com/ivueguide/skins/%s.zip' %(skin).replace (" ","%20") 
    try: 
        urllib2.urlopen(url)
        zipfile = os.path.join(PACKAGES,"%s.zip" % skin) 
        dp.create("iVue","Downloading %s" % skin,'')
        urllib.urlretrieve(url,zipfile,lambda nb, bs, fs, url=url: skins._pbhook(nb,bs,fs,url,dp))
        skins.extract(zipfile, SkinFolder)
        time.sleep(1)
        dp.close() 
    except urllib2.HTTPError, e:
            ADDON.setSetting('skin', 'Default')

if  ADDON.getSetting('focus.color') == 'text':
    ADDON.setSetting('focus.color', '[COLOR ffffffff]white[/COLOR]')
if  ADDON.getSetting('nofocus.color') == 'text':
    ADDON.setSetting('nofocus.color', '[COLOR ffffffff]white[/COLOR]') 

SKIN_FOLDER = 0
if ADDON.getSetting('customSkin.enabled') == 'true':
    if skinType == SKIN_FOLDER:
        if not ADDON.getSetting('customSkin.file') == '':
            customFile = str(ADDON.getSetting('customSkin.file'))
            skinName = os.path.split(os.path.dirname(customFile))[1]
            SkinFolder = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.ivueguide', 'resources', 'skins', '%s' % skinName))
            copytree(customFile, SkinFolder)
            ADDON.setSetting('customSkin.enabled', 'false')
            ADDON.setSetting('skin', skinName)
 
import gui, settings
import utils, base64
import sys


#addons ini fix start
import shutil
# set filepath
addons_data_ini_path = xbmc.translatePath('special://profile/addon_data/plugin.video.IVUEcreator/addons_index.ini')
old_ini_path = xbmc.translatePath('special://home/addons/plugin.video.IVUEcreator/addons_index.ini')

if os.path.exists(old_ini_path):
    shutil.move(old_ini_path, addons_data_ini_path)
#addons ini end


settings.setUrl()

try:
	w = gui.TVGuide()
	w.doModal()
	del w

except urllib2.HTTPError, e:
		if e.code == 401:
			utils.notify(addon_id, ae)
		else:
		    utils.notify(addon_id, e)
import xbmc, xbmcgui, shutil, urllib2, urllib, os, xbmcaddon, zipfile, time
import shutil

ADDONID = 'script.ivueguide'
ADDON = xbmcaddon.Addon(ADDONID)
PACKAGES       = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages'))
TEMP =	  ADDON.getSetting('tempskin')
USER_AGENT     = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
d = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
path = xbmc.translatePath(os.path.join('special://home', 'addons', 'script.ivueguide', 'resources', 'skins'))
prnum=""
try:
    prnum= sys.argv[ 1 ]
except:
    pass

def openURL(url):
	  req = urllib2.Request(url)
	  req.add_header('User-Agent', USER_AGENT)
	  response = urllib2.urlopen(req)
	  link=response.read()
	  response.close()
	  return link

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
		percent = min((numblocks*blocksize*100)/filesize, 100)
		print 'done' +str(percent)+'%'
		dp.update(percent)
	except:
		percent = 100
		dp.update(percent)
	if dp.iscanceled():
		raise Exception("Cancelled")
		dp.close()

def extract(_in, _out):
	dp = xbmcgui.DialogProgress()
	zin    = zipfile.ZipFile(_in,  'r')
	nFiles = float(len(zin.infolist()))
	count  = 0
	for item in zin.infolist():
		count += 1
		update = count / nFiles * 100
		zin.extract(item, _out)

def SkyVue():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/sky%20Vue.zip'  
	  zipfile = os.path.join(PACKAGES,"sky Vue.zip") 
	  dp.create("iVue","Downloading sky Vue",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path)
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/sky Vue"): 
	      ADDON.setSetting('skin', 'sky Vue')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'Sky Vue is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def SkyClas():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/Sky%20Classic.zip'  
	  zipfile = os.path.join(PACKAGES,"Sky Classic.zip") 
	  dp.create("iVue","Downloading Sky Classic",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path) 
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/Sky Classic"): 
	      ADDON.setSetting('skin', 'Sky Classic')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'Sky Classic is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def iVurgin():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/iVurgin.zip'  
	  zipfile = os.path.join(PACKAGES,"iVurgin.zip") 
	  dp.create("iVue","Downloading iVurgin",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path) 
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/iVurgin"): 
	      ADDON.setSetting('skin', 'iVurgin')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'iVurgin is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def FreeVue():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/FreeVue%20Play.zip'  
	  zipfile = os.path.join(PACKAGES,"FreeVue Play.zip") 
	  dp.create("iVue","Downloading FreeVue Play",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path) 
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/FreeVue Play"): 
	      ADDON.setSetting('skin', 'FreeVue Play')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'FreeVue Play is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def iVueClas():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/iVue%20Classic.zip'  
	  zipfile = os.path.join(PACKAGES,"iVue Classic.zip") 
	  dp.create("iVue","Downloading iVue Classic",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path) 
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/iVue Classic"): 
	      ADDON.setSetting('skin', 'iVue Classic')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'iVue Classic is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def iVueDef():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/iVue%20Default.zip'  
	  zipfile = os.path.join(PACKAGES,"iVue Default.zip") 
	  dp.create("iVue","Downloading iVue Default",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path) 
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/iVue Default"): 
	      ADDON.setSetting('skin', 'iVue Default')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'iVue Default is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def Mental():
	  zipurl = 'http://ivuetvguide.com/ivueguide/skins/Mental%20Acts.zip'  
	  zipfile = os.path.join(PACKAGES,"Mental Acts.zip") 
	  dp.create("iVue","Downloading Mental Acts",'')
	  urllib.urlretrieve(zipurl,zipfile,lambda nb, bs, fs, url=zipurl: _pbhook(nb,bs,fs,zipurl,dp))
	  extract(zipfile, path) 
	  time.sleep(1)
	  dp.close() 
	  if os.path.exists(path + "/Mental Acts"): 
	      ADDON.setSetting('skin', 'Mental Acts')
	      ADDON.setSetting('download.skin', 'false')
	      d.ok('Ivue', 'Download complete', '', 'Metal Acts is now set as current skin')
	  else:
	      d.ok('Ivue', 'Download failed', 'Please try downloading again')

def Custom():
	  folder = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages', 'customskin'))
	  if not os.path.exists(folder):
	      os.makedirs(folder)
	  choice = xbmc.Keyboard('','[COLOR fffea800][B]ENTER ZIP URL[/B][/COLOR]')
	  choice.setDefault(ADDON.getSetting('customSkin.url'))
	  choice.setHiddenInput(False)
	  choice .doModal()
	  input= choice.getText()
	  zipSkin = os.path.join(PACKAGES,'Custom.zip') 
	  dp.create("iVue","downloading skin from %s" % input,'')
	  urllib.urlretrieve(input,zipSkin,lambda nb, bs, fs, url=input: _pbhook(nb,bs,fs,input,dp))
	  extract(zipSkin, folder) 
	  time.sleep(1)
	  skinName = os.walk(folder).next()[1]
	  join = os.path.join(folder, *(skinName))
	  set = '%s' % join
	  ADDON.setSetting('customSkin.url', input)
	  splitName = os.path.basename(join)
	  SkinFolder = xbmc.translatePath(os.path.join('special://home', 'addons', 'script.ivueguide', 'resources', 'skins', '%s' % splitName))
	  if os.path.exists(SkinFolder):
	      shutil.rmtree(SkinFolder)
	  shutil.move(join, SkinFolder)
	  ADDON.setSetting('skin', splitName)
	  ADDON.setSetting('customSkin.enabled', 'false') 
	  shutil.rmtree(folder)
	  d.ok('Ivue', 'Download complete', '',"%s is now set as current skin" % splitName) 


if prnum == 'SkyVue':
    SkyVue()

elif prnum == 'SkyClas':
    SkyClas()

elif prnum == 'iVurgin':
    iVurgin()

elif prnum == 'FreeVue':
    FreeVue()

elif prnum == 'iVueClas':
    iVueClas()

elif prnum == 'iVueDef':
    iVueDef()

elif prnum == 'Mental':
    Mental()

elif prnum == 'Custom':
    Custom()
 

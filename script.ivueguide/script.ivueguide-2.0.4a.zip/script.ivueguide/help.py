import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time, xbmcvfs

mode='run_help'

def Help_Txt():
    path_to_text = xbmc.translatePath(os.path.join('special://home/addons/script.ivueguide','Help.txt'))
    try:
        f = open(path_to_text)
        lines = f.read()
    except Exception as e:
        message('unable to open Help','Error')
        return
    xbmc.executebuiltin("ActivateWindow(10147)")
    controller = xbmcgui.Window(10147)
    xbmc.sleep(500)
    controller.getControl(1).setLabel('Help')
    controller.getControl(5).setText(str(lines))
    return
	
if mode=='run_help' : Help_Txt()	
New add.py cleaned up and faster.
Will generate Dexter.ini and aPVR.ini
as long as both Dexter or A PVR is enabled.
this script can be added to settings.xml to run the plugin
<setting label="Add PVR and INI" type="action" action="RunScript($CWD/add.py) " />

The JDM Team working with IVUE team to deliver new improvements and features.

 better plugin compatibilty 
 
 added auto favorites

 added auto PVR detection

 fixed the auto link to widen the selection

 added PNG folder to resoursces

 tidy up addons ini and add BBCiplayerwww,  ITV 

 now able to use second ini from custom selection ( needs to be called addons2.ini) will automerge
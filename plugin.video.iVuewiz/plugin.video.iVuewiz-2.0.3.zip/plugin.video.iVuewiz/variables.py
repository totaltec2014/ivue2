import xbmc, xbmcaddon, xbmcgui, xbmcplugin, os, sys, xbmcvfs, glob, subprocess, zipfile
import shutil
import urllib2,urllib
import re
import time
import datetime
from datetime import date, datetime, timedelta
from sqlite3 import dbapi2 as database
try:
	import json as simplejson 
except:
	import simplejson


###############################################################################
#						                                                  XBMC ARGUMENTS
###############################################################################

dialog = xbmcgui.Dialog()
dialogProgress  = xbmcgui.DialogProgress()
currentKodi = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
setSkin  = xbmc.getSkinDir()

###############################################################################
#						                                                  GLOBAL PATHS
###############################################################################

addon_ID = 'plugin.video.iVuewiz'
ivueaddon_ID  = 'script.ivueguide'
creatoraddon_ID  = 'plugin.video.IVUEcreator'
intervueaddon_ID  = 'plugin.video.intervue'
addonTitle  = '[COLOR ffff7e14]iVue Wizard[/COLOR]'
addon = xbmcaddon.Addon(addon_ID)
home = xbmc.translatePath('special://home/')
profile  = xbmc.translatePath('special://profile/')
addons = os.path.join(home, 'addons')
addonData  = os.path.join(profile, 'addon_data', addon_ID)
userData  = xbmc.translatePath('special://userdata')
databasePath = xbmc.translatePath('special://profile/Database')
addons27 = os.path.join(databasePath, 'Addons27.db')
packagesdir =  xbmc.translatePath(os.path.join(addons,'packages',''))
xmlTemp = os.path.join(packagesdir, 'xmlfix.zip')
namesTemp = os.path.join(packagesdir, 'names.zip')
addonsTemp = os.path.join(packagesdir, 'ivuetvguide.zip')
packagesdir    =  xbmc.translatePath(os.path.join('special://home/addons/packages',''))
thumbnails    =  xbmc.translatePath('special://home/userdata/Thumbnails')
cachePath = os.path.join(home, 'cache')
tempPath = xbmc.translatePath('special://temp')
textures  = xbmc.translatePath('special://home/userdata/Database/Textures13.db')
kodilog = xbmc.translatePath('special://logpath/kodi.log')
kodiold = xbmc.translatePath('special://logpath/kodi.old.log')
favourites  =  xbmc.translatePath(os.path.join(profile,'favourites.xml'))
ivuefolder = os.path.join(profile, 'addon_data', ivueaddon_ID)
ivuelayout = os.path.join(ivuefolder, 'resources', 'guide_setups')
creatorfolder = os.path.join(profile, 'addon_data', creatoraddon_ID)
master = os.path.join(ivuefolder, 'master.db')
fanart = os.path.join(addons, addon_ID, 'fanart.jpg')
icon   = os.path.join(addons, addon_ID, 'icon.png')
images = xbmc.translatePath(os.path.join(addons, addon_ID, 'resources', 'art'))
DefaultNoteImage= os.path.join(images, 'ContentPanel.jpg')
focus = os.path.join(images, 'btn_start_bg1.png')
nofocus	= os.path.join(images, 'btn_start_glow_active.png')

###############################################################################
#						                                                  GLOBAL URLS
###############################################################################


latestAddons = 'https://raw.githubusercontent.com/totaltec2014/ivue2/master/addons.xml'
baseUrl = "http://ivuetvguide.com/toolbox/"
addonsInstall = baseUrl+'/ivuetvguide.zip'
namesInstall = baseUrl+'/names.zip'
xmlfixInstall = baseUrl+'/xmlfix.zip'
###############################################################################
#						                                                  GLOBAL SETTINGS
###############################################################################

backupPath  =  addon.getSetting('backup') 
startup = addon.getSetting('startup')
installedKodi = addon.getSetting('kodi')


###############################################################################
#						                                                  GLOBAL REQUESTS
###############################################################################

jsonGetCodec = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"videoplayer.usemediacodec"}, "id":1}'
jsonSetCodec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"videoplayer.usemediacodec", "value":%s},"id":1}'

codec = simplejson.loads(xbmc.executeJSONRPC(jsonGetCodec))

jsonGetSurfaceCodec = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue", "params":{"setting":"videoplayer.usemediacodecsurface"}, "id":1}'
jsonSetSurfaceCodec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"videoplayer.usemediacodecsurface", "value":%s},"id":1}'

surfaceCodec = simplejson.loads(xbmc.executeJSONRPC(jsonGetSurfaceCodec))

backupheader = "Backup In Progress"
backupinfo1 = "Archiving..."
backupinfo2 = ""
backupinfo3 = "Please Wait"
backupignoreDirs =  [addon_ID, 'cache', 'system', 'temp', 'Thumbnails']
backupignoreFiles = ["xbmc.log","xbmc.old.log","kodi.log","kodi.old.log","Textures13.db"]
ignorefresh = [addon_ID, 'xbmc.repo.ivueguide', 'service.xbmc.versioncheck', 'Addons26.db', 'Addons27.db', 'kodi.log', 'Textures13.db', 'commoncache.db']


space = '[COLOR ff191970][B]-------------------------------------------------[/B][/COLOR]'






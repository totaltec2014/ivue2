import utils
from variables import*

addon.setSetting('kodi', '%s' % (currentKodi))
###############################################################################
#						                                                          WELCOME 
###############################################################################
wizard = xbmcaddon.Addon(addon_ID).getAddonInfo('version')
addonslink = utils.openURL(latestAddons).replace('\n','').replace('\r','').replace('\t','')

info = None
ivueinstalled = '[COLOR ffff7e14]N/A[/COLOR]'
creatorinstalled = '[COLOR ffff7e14]N/A[/COLOR]'
intervueinstalled = '[COLOR ffff7e14]N/A[/COLOR]'
wizardinstalled = '[COLOR lime]%s[/COLOR]' % (wizard)
latestwizard = xbmcaddon.Addon(id=addon_ID).getAddonInfo('version')
  

if utils.addonCheck(ivueaddon_ID):
    ivue = xbmcaddon.Addon(id=ivueaddon_ID).getAddonInfo('version')
    ivueinstalled = '[COLOR lime]%s[/COLOR]' %(ivue)   
    ivuematch = re.compile('id="%s".+?ersion="(.+?)"' % ivueaddon_ID).findall(addonslink)

    if len(ivuematch) > 0:
        latestivue = ivuematch[0]

        if latestivue > ivue:
            ivueinstalled = '[COLOR red]%s[/COLOR]' %(ivue)
            info = True

if utils.addonCheck(creatoraddon_ID):
    creator = xbmcaddon.Addon(id=creatoraddon_ID).getAddonInfo('version')
    creatorinstalled = '[COLOR lime]%s[/COLOR]' %(creator)
    creatormatch = re.compile('id="%s".+?ersion="(.+?)"' % creatoraddon_ID).findall(addonslink)

    if len(creatormatch) > 0:
        latestcreator = creatormatch[0]

        if latestcreator > creator:
            creatorinstalled = '[COLOR red]%s[/COLOR]' %(creator)
            info = True
			
if utils.addonCheck(intervueaddon_ID):
    intervue = xbmcaddon.Addon(id=intervueaddon_ID).getAddonInfo('version')
    intervueinstalled = '[COLOR lime]%s[/COLOR]' %(intervue)
    intervuematch = re.compile('id="%s".+?ersion="(.+?)"' % intervueaddon_ID).findall(addonslink)

    if len(intervuematch) > 0:
        latestintervue = intervuematch[0]

        if latestintervue > intervue:
            intervueinstalled = '[COLOR red]%s[/COLOR]' %(intervue)
            info = True


wizardmatch          = re.compile('id="%s".+?ersion="(.+?)"' % addon_ID).findall(addonslink)

if len(wizardmatch) > 0:
    latestwizard = wizardmatch[0]

if latestwizard > wizard:
    wizardinstalled = '[COLOR red]%s[/COLOR]' %(wizard)
    info = True


welcome = "[B][COLOR ffff7e14]WELCOME TO THE IVUE WIZARD[/COLOR][/B]\n\n"

versioninfo = "Current iVue TV Guide Version = %s\n\nCurrent iVue Creator Version = %s\n\nCurrent iVue Wizard Version = %s\n\nCurrent InterVUE Version = %s\n\n[COLOR ffff7e14]For help and information regarding iVue please visit our forum[/COLOR]\n\nhttp://ivuetvguide.com/forum" % (ivueinstalled, creatorinstalled, wizardinstalled, intervueinstalled)

ivueinfo = welcome + versioninfo
check=utils.startup(noteType='t',noteMessage=ivueinfo,noteImage='')


if info:
    versioninfo = "Current iVue TV Guide Version = %s\n\nCurrent iVue Creator Version = %s\n\nCurrent iVue Wizard Version = %s\n\nCurrent InterVUE Version = %s\n\n[COLOR lime]Update available for one or more of the iVue addons[/COLOR]\n\nClick force to force repos to check for updates" % (ivueinstalled, creatorinstalled, wizardinstalled, intervueinstalled)

    ivueinfo = welcome + versioninfo
    check=utils.startup(force='true', noteType='t',noteMessage=ivueinfo,noteImage='')

if startup == 'true':
    check.doModal() 
    del check
else:
    from main import menu
    menu()





  



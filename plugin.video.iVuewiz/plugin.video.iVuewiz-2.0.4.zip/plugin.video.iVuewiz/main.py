import maintenance
import utils
import restart
import backup
from variables import*

def menu():

    setup= '[COLOR ffff7e14]Downloads:[/COLOR] System Setup'
    maintenance = '[COLOR ffff7e14]Maintenance:[/COLOR] Fix device'
    internet = '[COLOR ffff7e14]ookla:[/COLOR] Internet Speed Checker'
    backupRestore = '[COLOR ffff7e14]Backup / Restore:[/COLOR] Backup And Restore Tools'
    kodifix = '[COLOR ffff7e14]Kodi fix:[/COLOR] Enable all addons'

    if installedKodi > '17':
        option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Main Menu[/COLOR]', [setup, space, maintenance, space, backupRestore, space, internet, space, kodifix])
    else:
        option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Main Menu[/COLOR]', [setup, space, maintenance, space, backupRestore, space, internet]) 

    if option < 0:
	    return
    if option == 0:
	    downloads()
    if option == 1:
	    menu()
    if option == 2:
	    Maintain()
    if option == 3:
	    menu()
    if option == 4:
	    Backup()
    if option == 5:
	    menu()
    if option == 6:
	    xbmc.executebuiltin ( 'Runscript("special://home/addons/plugin.video.iVuewiz/ookla.py")' )
    if option == 7:
	    menu()
    if option == 8:
	    utils.enable17()

###############################################################################
#						                                                  DOWNLOAD MENU
###############################################################################

def downloads():
	addondownload = '[COLOR ffff7e14]Download Addons:[/COLOR] iVue TV guide and dependencies'
	namechange = '[COLOR ffff7e14]Download Name Change:[/COLOR] Name changes files for creator'
	option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Downloads[/COLOR]', [addondownload, space, namechange]) 

	if option < 0:
	    menu()

	if option == 1:
	    dialogProgress.create(addonTitle,"Downloading ",'', 'Please Wait')
	    try:
	        os.remove(addonsTemp)
	    except:
	        pass
	    utils.download(addonsInstall, addonsTemp, dialogProgress)
	    time.sleep(2)
	    dialogProgress.update(0,"", "Extracting Zip Please Wait")
	    utils.extractAll(addonsTemp,home,dialogProgress)
	    xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
	    xbmc.sleep(500)
	    dialog.ok(addonTitle, "iVue and dependencies have been installed please press ok to enable them","[COLOR ffff7e14]Brought To You By iVue Wizard[/COLOR]")
	    utils.enable17()	

	if option == 2:
	    downloads()

	if option == 3:
	    dialogProgress.create(addonTitle,"Downloading ",'', 'Please Wait')
	    try:
	        os.remove(namesTemp)
	    except:
	        pass
	    utils.download(namesInstall, namesTemp, dialogProgress)
	    time.sleep(2)
	    dialogProgress.update(0,"", "Extracting Zip Please Wait")
	    utils.extractAll(namesTemp,home,dialogProgress)
	    dialog.ok("iVue Wizard", "Channel name changes have been added please press ok to update links","[COLOR ffff7e14]Brought To You By iVue Wizard[/COLOR]")	
	    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.IVUEcreator/update)')


###############################################################################
#						                                                  MAINTENANCE MENU
###############################################################################   

def Maintain():

	if not os.path.exists(packagesdir):
		os.makedirs(packagesdir)

	try:
	        if os.path.exists(cachePath):
		    cacheSize = maintenance.get_size(cachePath)
                else:
		    cacheSize = maintenance.get_size(tempPath)
		packageSize = maintenance.get_size(packagesdir)
		thumbSize    = maintenance.get_size(thumbnails)
	except: pass
	
	try:
		convertCache    = maintenance.convertSize(cacheSize)
		convertPackages = maintenance.convertSize(packageSize)
		convertThumbs    = maintenance.convertSize(thumbSize)
	except: pass

	cache = '[COLOR ff9f9f9f]Clear Cache = [/COLOR]' + str(convertCache)
	packages = '[COLOR ff9f9f9f]Clear Packages = [/COLOR]' + str(convertPackages)
	thumbs = '[COLOR ff9f9f9f]Delete Thumbnails = [/COLOR]' + str(convertThumbs) 
	softreset = '[COLOR ffff7e14]iVue Soft Reset:[/COLOR] fix for xml loading problems'
	hardreset = '[COLOR ffff7e14]iVue Hard Reset:[/COLOR] Wipe iVue setup except skins'
	force = '[COLOR ffff7e14]Force Repo updates:[/COLOR] fix addons not auto updating'
	logerrors = '[COLOR ffff7e14]Logged Errors:[/COLOR] View logs and errors'
	fresh = '[COLOR ffff7e14]Fresh Start:[/COLOR] Wipe Current setup leaving just the wizard and ivue repo'
	if xbmc.getCondVisibility('system.platform.android'):

	    if codec == False:
	        media = '[COLOR ffff7e14]Media Codec:[/COLOR]  Disabled'
	    else: 
	        media = '[COLOR ffff7e14]Media Codec:[/COLOR]  Enabled'

	    if surfaceCodec == False:
	        surfacemedia = '[COLOR ffff7e14]Media Codec Surface:[/COLOR]  Disabled'
	    else: 
	        surfacemedia = '[COLOR ffff7e14]Media Codec Surface:[/COLOR]  Enabled'

	    option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Maintain[/COLOR]', [softreset, hardreset, space, cache, packages, thumbs, space, force, space, logerrors, space, media, surfacemedia, space, fresh]) 

	else:
	    option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Maintain[/COLOR]', [softreset, hardreset, space, cache, packages, thumbs, space, force, space, logerrors, space, fresh]) 

	if option < 0:
	    menu()
	if option == 0:
	    import SoftReset
	if option == 1:
	    import HardReset
	if option in [2,6,8,10,13]:
	    Maintain()
	if option == 3:
	    maintenance.clearCache()
	if option == 4:
	    maintenance.clearPackages()
	if option == 5:
	    maintenance.removeThumbs()
	if option == 7:
	    utils.forceUpdate() 
	if option == 9:
	    maintenance.logs() 
	if option == 11:
	    if xbmc.getCondVisibility('system.platform.android'):
	        if codec == False:
	            xbmc.executeJSONRPC(jsonSetCodec % "true")
	            dialog.ok(addonTitle, "Media Codec Enabled")
	        else:
	            xbmc.executeJSONRPC(jsonSetCodec  % "false")
	            dialog.ok(addonTitle, "Media Codec Disabled")
	    else:
	        option = 14
	if option == 12:
	    if xbmc.getCondVisibility('system.platform.android'):
	        if surfaceCodec == False:
	            xbmc.executeJSONRPC(jsonSetSurfaceCodec % "true")
	            dialog.ok(addonTitle, "Media Codec (Surface) Enabled")
	        else:
	            xbmc.executeJSONRPC(jsonSetSurfaceCodec  % "false")
	            dialog.ok(addonTitle, "Media Codec (Surface) Disabled")
	if option == 14:
	    restart.freshStart() 

###############################################################################
#						                                                  BACKUP MENU
###############################################################################


def Backup():

    backupbuild= '[COLOR ffff7e14]Backup:[/COLOR] complete build'
    backupfavs= '[COLOR ffff7e14]Backup:[/COLOR] favourites.xml'
    backupmaster= '[COLOR ffff7e14]Backup:[/COLOR] iVue master.db file'
    backuplayout= '[COLOR ffff7e14]Backup:[/COLOR] iVue channel layout'
    backupivue= '[COLOR ffff7e14]Backup:[/COLOR] All iVue data'
    backupcreator= '[COLOR ffff7e14]Backup:[/COLOR] iVue creator add-on data'
    restorebuild= '[COLOR ffff7e14] Restore:[/COLOR] complete build'
    restorefavs= '[COLOR ffff7e14] Restore:[/COLOR] favourites.xml'
    restoremaster= '[COLOR ffff7e14] Restore:[/COLOR] iVue master.db file'
    restorelayout= '[COLOR ffff7e14] Restore:[/COLOR] iVue channel layout'
    restoreivue = '[COLOR ffff7e14] Restore:[/COLOR] iVue add-on data'
    restorecreator= '[COLOR ffff7e14] Restore:[/COLOR] iVue creator add-on data'
    option = dialog.select(addonTitle+ ' [COLOR ffff7e14]Backup / Restore[/COLOR]', [backupmaster, backuplayout, backupivue, backupcreator, backupfavs, backupbuild, space, restoremaster, restorelayout, restoreivue, restorecreator, restorefavs, restorebuild]) 

    if option < 0:
      menu()
    if option == 0:
      backup.BackUp(master, 'master.db')
      Backup()    
    if option == 1:
      backup.BackUp(ivuelayout, 'Channel Layouts')
      Backup()
    if option == 2:
      backup.BackUp(ivuefolder, ivueaddon_ID)
      Backup()
    if option == 3:
      backup.BackUp(creatorfolder, creatoraddon_ID)
      Backup()
    if option == 4:
      backup.BackUp(favourites, 'favourites.xml')
      Backup()
    if option == 5:
      backup.BackUp(home, 'setup')
      Backup()
    if option == 6:
      Backup()
    if option == 7:
      dialogProgress.create(addonTitle,"Extracting master.db:",'', '')
      utils.extractAll(os.path.join(backupPath, 'master.db.zip'),ivuefolder,dialogProgress)
      xbmc.sleep(500)
      dialog.ok(addonTitle, "master.db restored")
      Backup()
    if option == 8:
      dialogProgress.create(addonTitle,"Extracting ivue Channel Layouts:",'', '')
      utils.extractAll(os.path.join(backupPath, 'Channel Layouts.zip'),ivuelayout,dialogProgress)
      xbmc.sleep(500)
      dialog.ok(addonTitle, "iVue channel Layouts restored")
    if option == 9:
      dialogProgress.create(addonTitle,"Extracting %s:" % ivueaddon_ID,'', '')
      utils.extractAll(os.path.join(backupPath, ivueaddon_ID+'.zip'),ivuefolder,dialogProgress)
      xbmc.sleep(500)
      dialog.ok(addonTitle, "iVue data restored")
    if option == 10:
      dialogProgress.create(addonTitle,"Extracting %s:" % creatoraddon_ID,'', '')
      utils.extractAll(os.path.join(backupPath, creatoraddon_ID+'.zip'),creatorfolder,dialogProgress)
      xbmc.sleep(500)
      dialog.ok(addonTitle, "iVue Creator setup restored")
    if option ==11:
      dialogProgress.create(addonTitle,"Extracting favourites.xml:" ,'', '')
      utils.extractAll(os.path.join(backupPath, 'favourites.xml.zip'),profile,dialogProgress)
      xbmc.sleep(500)
      dialog.ok(addonTitle, "favourites.xml restored")
    if option == 12:
      dialogProgress.create(addonTitle,"Extracting Setup:",'', '')
      utils.extractAll(os.path.join(backupPath, 'setup.zip'),home,dialogProgress)
      xbmc.sleep(500)
      dialog.ok(addonTitle, "Setup restored")



if __name__ == '__main__' :
    menu()


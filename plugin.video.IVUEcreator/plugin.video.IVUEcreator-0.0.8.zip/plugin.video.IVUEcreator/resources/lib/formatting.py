import os, xbmc, xbmcgui, xbmcaddon,xbmcplugin
import re
import xml.etree.ElementTree as ET
import ConfigParser
from difflib import SequenceMatcher as SM

debug = False
ratio_match_val = 0.89
path_to_ivue = xbmc.translatePath('special://profile/addon_data/script.ivueguide')
settings_xml = os.path.join(path_to_ivue, "settings.xml")
guides_ini = os.path.join(path_to_ivue, "guides.ini")

def strip_label(label):
    label = ''.join(e for e in label if e.isalnum())
    return label.lower()


def message(message):
    dialog = xbmcgui.Dialog()
    dialog.ok(" Debug", message)


def changenumbers(s, reverse = 0):
    numbers = {'1' : 'one' ,'2' : 'two', '3' : 'three', '4':'four', '5' : 'five',}

    for src, target in numbers.iteritems():
        s = re.sub(src, target, s)

    return s

def get_clean_names():

    xml = ET.iterparse(settings_xml, events=('end',))
    for event, elem in xml:
        if elem.tag == "setting":
            if elem.get("id")== "xmltv.type":
                user_xml = elem.get("value")

    config = ConfigParser.RawConfigParser()
    config.read(guides_ini)
    sections = config.sections()

    for section in sections:
        if config.get(section, "id") == user_xml:
            masterxml = config.get(section, 'file')

    masterxml_path = os.path.join(path_to_ivue, masterxml)

    clean_names = {"clean_name": list(),
                   "stripped_name": list(),
                   "clean_id": list(),
                   "stripped_id": list(), }

    xml = ET.iterparse(masterxml_path, events=('end',))
    for event, elem in xml:
        if elem.tag == "channel":
            clean_id = elem.get('id')
            clean_label = elem.find('display-name').text
            clean_label = re.sub(r"\n", ' ', clean_label)
            clean_names["clean_name"].append(clean_label)
            clean_names["clean_id"].append(clean_id)
            clean_names["stripped_name"].append(strip_label(clean_label))
            clean_names["stripped_id"].append(strip_label(clean_id))

    return clean_names


def clean_label(dirty_label, clean_names):

    orig_label = dirty_label
    stripped_label = strip_label(changenumbers(dirty_label))
    addon_path = xbmcaddon.Addon().getAddonInfo("path")

    if debug:
        test_file = os.path.join(addon_path, 'test.txt')
        f = open(test_file, 'a')

    for ii in range(0, len(clean_names["stripped_name"])):

        ratio = SM(None, stripped_label, changenumbers(clean_names["stripped_id"][ii])).ratio()

        if ratio >= ratio_match_val:

            if debug:

                f.write("orig_label: " + orig_label + '\n'\
                        "stripped_label: " + stripped_label + '\n'\
                        "stripped_ivuename: " + clean_names["stripped_name"][ii] + '\n'\
                        "clean_ivueid: " + clean_names["clean_id"][ii]+ '\n'\
                        "clean_ivuename: " + clean_names["clean_name"][ii]+ '\n'\
                    "ratio: " + str(ratio) + "\n\n")

            return clean_names["clean_name"][ii]

        ratio = SM(None, stripped_label, changenumbers(clean_names["stripped_name"][ii])).ratio()

        if ratio >= ratio_match_val:

            if debug:

                f.write("orig_label: " + orig_label + '\n'\
                        "stripped_label: " + stripped_label + '\n'\
                        "stripped_ivuename: " + clean_names["stripped_name"][ii] + '\n'\
                        "clean_ivueid: " + clean_names["clean_id"][ii]+ '\n'\
                        "clean_ivuename: " + clean_names["clean_name"][ii]+ '\n'\
                        "ratio: " + str(ratio) + "\n\n")

            return clean_names["clean_name"][ii]

    if debug:
        f.close()

    return orig_label

def remove_tags(label):

    for rep in [r"\[/?[BI]\]", r"\[/?COLOR.*?\]",]:
        label = re.sub(rep, '', label)

    return label

def remove_formatting(label, clean_names):

    for replace in ['facebook', 'twitter','updated','link','welcome','enter','latest','playlist','streams','beware','property',]:

        if replace in label.lower():
            return '<nolabel>'


    label = remove_tags(label)


    for replace in  [':','-','_',]:

        if len(label) > 3 and label.lower()[:1] is not 'bt' and label[2] == replace:
            label = label.split(replace,1)[1]

    replace = ["usa/ca",
               "local",
               "sports uk english",
               "movie channels",
               "uk english",
               "us english",
               "uk english",
               "english",
               "sd",
               'hd',
               'uk',
               'entertainment',]

    for rep in replace:
        label = re.sub(rep, '', label.lower())

    label = re.sub('\(.*?\)', '', label)

    label = re.sub('[^A-Za-z0-9]+', ' ', label)

    for replace in ['natgeo', 'nat geo']:

        if replace in label.lower():
            label = re.sub(replace, 'National Geographic', label.lower())

    label = label.strip()

    if 'ccloudtv.org' in label.lower(): # to become if this is ccloud plugin section mebbe
        label = re.sub('ccloud.org', '', label)


    if "sky" in label.lower():

        if "sport" not in label.lower():


            if label[:3] == "sky" and \
                    ("movies" not in label.lower() and \
                                 "atlantic" not in label.lower() and \
                                 "living" not in label.lower() and \
                                 "arts" not in label.lower() and \
                                 'one' not in label.lower() and \
                                 'news' not in label.lower() and \
                                 'two' not in label.lower()):
                label = re.sub("sky", '', label)

        if label[:5] == "sky uk":
            label = re.sub("sky uk", "", label)



    cl_label = clean_label(label.strip(), clean_names)

    if len(cl_label) < 1:
        cl_label = '<nolabel>'
    return cl_label




import os, xbmc, xbmcgui, xbmcaddon,xbmcplugin
import re
import xml.etree.ElementTree as ET
import ConfigParser
from difflib import SequenceMatcher as SM

debug = False
ratio_match_val = 0.90
path_to_ivue = xbmc.translatePath('special://profile/addon_data/script.ivueguide')
settings_xml = os.path.join(path_to_ivue, "settings.xml")
guides_ini = os.path.join(path_to_ivue, "guides.ini")
addon_path = xbmcaddon.Addon().getAddonInfo("path")

def strip_label(label):

    label = ''.join(e for e in label if e.isalnum()) #seems to work better than regex approach for some strange reason, probably human error i.e ME
    return label.lower()


def message(message):

    dialog = xbmcgui.Dialog()
    dialog.ok(" Debug", message)


def changenumbers(s):

    numbers = {'1' : 'one' ,'2' : 'two', '3' : 'three', '4':'four', '5' : 'five' ,'6' : 'six' ,
               '7' : 'seven', '8' : 'eight', '9':'nine', '10' : 'ten', '11':'eleven', '12' : 'twelve',}

    for src, target in numbers.iteritems():
        if src in s:
            s = s.replace(src, target)

    return s


def get_clean_names():

    xml = ET.iterparse(settings_xml, events=('end',))

    for event, elem in xml:
        if elem.tag == "setting":
            if elem.get("id")== "xmltv.type":
                user_xml = elem.get("value")

    config = ConfigParser.RawConfigParser()
    config.read(guides_ini)
    sections = config.sections()

    for section in sections:
        if config.get(section, "id") == user_xml:
            masterxml = config.get(section, 'file')
    try:

        masterxml_path = os.path.join(path_to_ivue, masterxml)
    except Exception as e:
        message('Error: Missing guides file, please change ivue guide.xml to generate files.'+str(e))

        #die, but so un-pythonic :S :/

    clean_names = {"clean_name": list(),
                   "stripped_name": list(),
                   "clean_id": list(),
                   "stripped_id": list(), }

    xml = ET.iterparse(masterxml_path, events=('end',))

    for event, elem in xml:
        if elem.tag == "channel":
            clean_id = elem.get('id')
            clean_label = elem.find('display-name').text
            clean_label = clean_label.replace(r"\n", ' ')
            clean_names["clean_name"].append(clean_label)
            clean_names["clean_id"].append(clean_id)
            clean_names["stripped_name"].append(strip_label(clean_label))
            clean_names["stripped_id"].append(strip_label(clean_id))

    return clean_names


def clean_label(dirty_label, clean_names):

    orig_label = dirty_label
    stripped_label = strip_label(changenumbers(dirty_label))#label numbers to change to alpha format to improve chances of accurate match


    for ii in range(0, len(clean_names["stripped_name"])):

        # do same to channel numbers
        if SM(None, stripped_label, changenumbers(clean_names["stripped_id"][ii])).quick_ratio() >= ratio_match_val or \
           SM(None, stripped_label, changenumbers(clean_names["stripped_name"][ii])).quick_ratio() >= ratio_match_val:

            return clean_names["clean_name"][ii]

    return orig_label

def remove_tags(label):

    for rep in [r"\[/?[BI]\]", r"\[/?COLOR.*?\]",]:
        label = re.sub(rep, '', label)
    label = re.sub(r"[^A-Za-z0-9]", ' ', label)

    return label


def remove_formatting(label, clean_names):

    for replace in ['facebook', 'twitter','updated','link','welcome','enter','latest','playlist','streams','beware','property',]:

        if replace in label.lower():
            return '<nolabel>'

    label = remove_tags(label)

    for replace in  [':','-','_',]:

        if len(label) > 3 and label.lower()[:1] is not 'bt' and label[2] == replace:
            label = label.split(replace,1)[1]

    replace = ["usa/ca",
               "local",
               "sports uk english",
               "movie channels",
               "uk english",
               "us english",
               "uk english",
               "english",
               'london',
               "sd",
               "skyuk",
               'ccloudtv.org',
               'uk',
               'entertainment',]

    for rep in replace:
        label =  label.lower().replace(rep, '')

    label = re.sub(r'\(.*?\)', '', label.lower())

    label = re.sub('[^A-Za-z0-9&+]+', ' ', label)

    for replace in ['natgeo', 'nat geo']:

        if replace in label.lower():
            label = label.replace(replace, 'National Geographic')

    label = label.strip()

    if "sky" in label.lower():

        if "sport" not in label.lower():

            if label[:5].lower() == "sky uk":
                label = label.lower().replace("sky uk", "")

            if label[:2] == "sky" and \
                    ("movies" not in label[3:].lower() and \
                                 "atlantic" not in label[3:].lower() and \
                                 "disney" not in label[3:].lower() and \
                                 "family" not in label[3:].lower() and \
                                 "sci" not in label[3:].lower() and \
                                 "living" not in label[3:].lower() and \
                                 "art" not in label[3:].lower() and \
                                 'one' not in label[3:].lower() and \
                                 'news' not in label[3:].lower() and \
                                 'two' not in label[3:].lower()):
                label = label.replace("sky", '')

    cl_label = clean_label(label.strip(), clean_names)

    if len(cl_label) < 1:
        return '<nolabel>'
    else:
        return cl_label




import xbmc,xbmcaddon,xbmcvfs,xbmcgui, ConfigParser, os,re,time,urllib
from rpc import RPC
from xbmcswift2 import Plugin
from resources.lib.formatting import *


plugin = Plugin()
big_list_view = False
addons_ini_path = xbmc.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo("path"),'addons_index.ini'))


def log2(v):
    xbmc.log(repr(v))
    
    

def log(v):
    xbmc.log(re.sub(',',',\n',repr(v)))
    
    

def sanitycheck(title, string):
    dialog = xbmcgui.Dialog()
    response = dialog.yesno(title, string)
    return response




def message(message, title ='Debug'):
    dialog = xbmcgui.Dialog()
    dialog.ok(title, message)
    
    

def delete_section(id):
    folder = plugin.get_setting("addons.folder")
    file = plugin.get_setting("addons.file")
    filename = os.path.join(folder, file)

    config = ConfigParser.ConfigParser()
    config.optionxform = str
    filename = xbmc.translatePath(filename)
    config.read(filename)

    if config.has_section(id):
        config.remove_section(id)

    with open(filename, 'wb') as configfile:
        config.write(configfile)
        
def get_tv_path(icon_name):
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    return os.path.join(addon_path, 'resources', 'img', icon_name+".png")        

def get_icon_path(id):

    return os.path.join(xbmc.translatePath('special://home/'),'addons', id, "icon.png")



@plugin.route('/addon/<id>')
def addon(id):
    addon = plugin.get_storage(id)
    items = []
    for name in sorted(addon):
        url = addon[name]
        items.append(
        {
            'label': name,
            'path': url,
            'icon': get_icon_path(id),
            'thumbnail':get_icon_path(id),
            'is_playable':True,
        })
    return items


@plugin.route('/player')
def player():
    if not plugin.get_setting('addons.folder'):
        dialog = xbmcgui.Dialog()
        dialog.notification("Ivue creator", "Set Folder",xbmcgui.NOTIFICATION_ERROR )
        xbmcaddon.Addon ('plugin.video.IVUEcreator').openSettings()

    addons = plugin.get_storage("addons")
    for a in addons.keys():
        add = plugin.get_storage(a)
        add.clear()
    addons.clear()

    folder = plugin.get_setting("addons.folder")
    file = plugin.get_setting("addons.file")
    filename = os.path.join(folder,file)

    config = ConfigParser.ConfigParser()
    config.optionxform = str
    filename = xbmc.translatePath(filename)
    config.read(filename)

    addon = None
    sections = config.sections()
    for section in sections:

        addons[section] = section
        addon = plugin.get_storage(section)
        addon.clear()

        items = config.items(section)
        ####this part needs to sort out the var[key] issue overwriting url when dupe exists
        for item in items:
            if '[u' in item[1]:
                stream = item[1][2:-1].split(', u')
                for s in stream:
                    s = s[1:-1]
                    name = item[0]
                    url = s
            else:
                (name, url) = item

            if url and addon is not None:
                addon[name] = url
    items = []
    for id in sorted(addons):
        items.append(
        {
            'label': id,
            'path': plugin.url_for('addon',id=id),
            'thumbnail':get_icon_path(id),
        })
    return items



@plugin.route('/play/<url>')
def play(url):
    xbmc.executebuiltin('PlayMedia(%s)' % url)
    

@plugin.route('/pvr_subscribe')
def pvr_subscribe():
    plugin.set_setting("pvr.subscribe","true")
    xbmc.executebuiltin('Container.Refresh')
    
@plugin.route('/pvr_unsubscribe')
def pvr_unsubscribe():
    plugin.set_setting("pvr.subscribe","false")
    xbmc.executebuiltin('Container.Refresh')
    

@plugin.route('/add_folder/<id>/<path>/<label>')
def add_folder(id,path,label):
    dp = xbmcgui.DialogProgress()
    dp.create('Updating links', "working...")
    config = ConfigParser.ConfigParser()
    config.optionxform = str
    config.read(addons_ini_path)

    if config.has_section(id) == False:
        config.add_section(id)

    config.set(id, remove_tags(label).strip(), path)

    with open(addons_ini_path, 'wb') as configfile:
        config.write(configfile)

    addtoini(id,path,dp)
    xbmc.executebuiltin('Container.Refresh')
    
    
    
@plugin.route('/update_addon/<id>')
def update_addon(id):
    
    if not sanitycheck('Update '+id, 'are you sure?'):
        return
    
    dp = xbmcgui.DialogProgress()
    dp.create('Updating links', "working...")

    delete_section(id)

    config = ConfigParser.ConfigParser()
    config.optionxform = str
    config.read(addons_ini_path)
    
    items = config.items(id)
    num_of_items = len(items)
    
    dp.update(10, str(num_of_items)+' section(s) to update')
    
    for name, path in items:
        addtoini(id, path, dp)
        num_of_items -= 1
        dp.update(25, str(num_of_items) + ' section(s) to update')
    dp.close()


@plugin.route('/delete_folder/<id>/<path>/<label>')
def delete_folder(id, path,label):
    
    if sanitycheck('Delete ' + str(label), 'Are you sure?'):

        config = ConfigParser.ConfigParser()
        config.optionxform = str

        config.read(addons_ini_path)

        if config.has_section(id):
            items = config.items(id)
            for item in items:
                if item[1] == path:
                    config.remove_option(id,item[0])

        with open(addons_ini_path, 'wb') as configfile:
            config.write(configfile)
        xbmc.executebuiltin('Container.Refresh')
    else:
        pass



@plugin.route('/clear')
def clear():
    folder = plugin.get_setting("addons.folder")
    file = plugin.get_setting("addons.file")
    path_to_addons2 = xbmc.translatePath(os.path.join(folder,file))

    if sanitycheck('Delete all subs?', 'are you sure?'):

        if os.path.exists(path_to_addons2):
            os.remove(path_to_addons2)
        if os.path.exists(addons_ini_path):
            os.remove(addons_ini_path)

        message('Delete addons','Done')
        
        

@plugin.route('/remove_addon/<id>')
def remove_addon(id):

    storagePath = xbmc.translatePath('special://userdata/addon_data/plugin.video.IVUEcreator/.storage/%s' % id)
    path = "plugin://%s" % id

    if sanitycheck('Delete '+str(id),'Are you sure?'):

        config = ConfigParser.ConfigParser()
        config.optionxform = str

        config.read(addons_ini_path)

        if config.has_section(id):
            config.remove_section(id)
        with open(addons_ini_path, 'wb') as configfile:
            config.write(configfile)

        delete_section(id)

        os.remove(storagePath)

        message('Done', 'Delete '+str(id))

    xbmc.executebuiltin('Container.Refresh')
    

@plugin.route('/deleteaddon')
def deleteaddon():

    config = ConfigParser.ConfigParser()
    config.optionxform = str

    config.read(addons_ini_path)
    sections = config.sections()
    items = []
    for section in sections:
        items.append(
            {
                'label': section,
                'path': plugin.url_for('remove_addon', id=section),
                'thumbnail': get_icon_path(section),

            })
    return items


@plugin.route('/updateaddon')
def updateaddon():

    config = ConfigParser.ConfigParser()
    config.optionxform = str

    config.read(addons_ini_path)
    sections = config.sections()
    items = []
    for section in sections:
        items.append(
            {
                'label': section,
                'path': plugin.url_for('update_addon', id=section),
                'thumbnail': get_icon_path(section),

            })
    return items

@plugin.route('/folder/<id>/<path>')
def folder(id,path):

    config = ConfigParser.ConfigParser()
    config.optionxform = str

    config.read(addons_ini_path)

    folders = []

    if config.has_section(id):
        items = config.items(id)
        for item in items:
            folders.append(item[1])

    try:
        response = RPC.files.get_directory(media="files", directory=path, properties=["thumbnail"])
    except Exception as e:

        message(str(e))
        return False

    files = response["files"]
    dirs = dict([[remove_tags(f["label"]), f["file"]] for f in files if f["filetype"] == "directory"])
    links = {}
    thumbnails = {}
    for f in files:
        if f["filetype"] == "file":
            label = f["label"]
            file = f["file"]
            while (label in links):
                label = "%s." % label
            links[label] = file
            thumbnails[label] = f["thumbnail"]

    items = []

    for label in sorted(dirs):
        path = dirs[label]

        context_items = []
        if path in folders:
            fancy_label = "[COLOR yellow]%s[/COLOR] " % remove_tags(label)
            context_items.append(("[COLOR yellow]%s[/COLOR] " % 'Unsubscribe', 'XBMC.RunPlugin(%s)' % (plugin.url_for(delete_folder, id=id, path=path, label=label))))
        else:
            fancy_label = "%s" % remove_tags(label)
            context_items.append(("[COLOR yellow]%s[/COLOR] " % 'Subscribe', 'XBMC.RunPlugin(%s)' % (plugin.url_for(add_folder, id=id, path=path, label=label))))
        items.append(
        {
            'label': fancy_label,
            'path': plugin.url_for('folder',id=id, path=path),
            'thumbnail': get_icon_path(id),
            'context_menu': context_items,
        })

    for label in sorted(links):
        items.append(
        {
            'label': label,
            'path': plugin.url_for('play',url=links[label]),
            'thumbnail': thumbnails[label],
        })
    return items


@plugin.route('/pvr')
def pvr():
    index = 0
    urls = []
    channels = {}
    for group in ["radio","tv"]:
        urls = urls + xbmcvfs.listdir("pvr://channels/%s/All channels/" % group)[1]
    for group in ["radio","tv"]:
        groupid = "all%s" % group
        json_query = RPC.PVR.get_channels(channelgroupid=groupid, properties=[ "thumbnail", "channeltype", "hidden", "locked", "channel", "lastplayed", "broadcastnow" ] )
        if "channels" in json_query:
            for channel in json_query["channels"]:
                channelname = channel["label"]
                channelid = channel["channelid"]-1
                channellogo = channel['thumbnail']
                streamUrl = urls[index]
                index = index + 1
                url = "pvr://channels/%s/All channels/%s" % (group,streamUrl)
                channels[url] = channelname
    items = []
    for url in sorted(channels, key=lambda x: channels[x]):
        name = channels[url]
        items.append(
        {
            'label': name,
            'path': url,
            'is_playable': True,
        })
    return items

@plugin.route('/subscribe')
def subscribe():
    config = ConfigParser.ConfigParser()
    config.optionxform = str

    config.read(addons_ini_path)
    sections = config.sections()

    ids = {}
    for folder in sections:
        id = folder
        ids[id] = id
    all_addons = []
    for type in ["xbmc.addon.video", "xbmc.addon.audio"]:
        response = RPC.addons.get_addons(type=type,properties=["name", "thumbnail"])
        if "addons" in response:
            found_addons = response["addons"]
            all_addons = all_addons + found_addons

    seen = set()
    addons = []
    for addon in all_addons:
        if addon['addonid'] not in seen:
            addons.append(addon)
        seen.add(addon['addonid'])

    items = []

    pvr = plugin.get_setting('pvr.subscribe')
    context_items = []
    label = "PVR"
    if pvr == "true":
        fancy_label = "[COLOR yellow]%s[/COLOR] " % remove_tags(label)
        context_items.append(("[COLOR yellow][B]%s[/B][/COLOR] " % 'Unsubscribe', 'XBMC.RunPlugin(%s)' % (plugin.url_for(pvr_unsubscribe))))
    else:
        fancy_label = "%s" % remove_tags(label)
        context_items.append(("[COLOR yellow][B]%s[/B][/COLOR] " % 'Subscribe', 'XBMC.RunPlugin(%s)' % (plugin.url_for(pvr_subscribe))))
    items.append(
    {
        'label': fancy_label,
        'path': plugin.url_for('pvr'),
        'thumbnail':get_icon_path(''),
        'context_menu': context_items,
    })

    addons = sorted(addons, key=lambda addon: addon['name'].lower())
    for addon in addons:
        label = addon['name']

        id = addon['addonid']

        path = "plugin://%s" % id

        context_items = []
        if id in ids:
            fancy_label = "[COLOR yellow]%s[/COLOR] " % remove_tags(label)
            context_items.append(("[COLOR yellow][B]%s[/B][/COLOR] " % 'Unsubscribe', 'XBMC.RunPlugin(%s)' % (plugin.url_for(remove_addon, id=id))))
        else:
            fancy_label = "%s" % remove_tags(label)
            context_items.append(("[COLOR yellow][B]%s[/B][/COLOR] " % 'Subscribe', 'XBMC.RunPlugin(%s)' % (plugin.url_for(add_folder, id=id, path=path, label=label))))
        items.append(
        {
            'label': fancy_label,
            'path': plugin.url_for('folder',id=id, path=path),
            'thumbnail': get_icon_path(id),
            'context_menu': context_items,
        })
    return items


@plugin.route('/addtoini/<id>/<path>')
def addtoini(id,path,dp):

    dp.update(25)
    if id and path:

        folder = plugin.get_setting("addons.folder")
        file = plugin.get_setting("addons.file")
        filename = xbmc.translatePath(os.path.join(folder, file))
        try:
            response = RPC.files.get_directory(media="files", directory=path, properties=["thumbnail"])
        except Exception as e:
            message(str(e))
            return False

        files = response["files"]
        links = {}
        streams = {}
        thumbnails = {}
        if not id in streams:
            streams[id] = {}
        for f in files:
            if f["filetype"] == "file":
                label = f["label"]
                file = f["file"]
                while (label in links):
                    label = "%s." % label
                links[label] = file
                thumbnails[label] = f["thumbnail"]
                streams[id][label] = file
        dp.update(50, 'links retrieved, sorting results')

        config = ConfigParser.RawConfigParser()
        config.optionxform = str

        config.read(filename)

        clean_names = get_clean_names()

        for id in sorted(streams):
            count = 0
            if not config.has_section(id):
                config.add_section(id)

            channels = streams[id]
            for channel in sorted(channels):
                url = channels[channel].strip()
                label = remove_formatting(channel.strip(), clean_names)

                if '<nolabel>' not in label:
                    if config.has_option(id, label):
                        count += 1
                        config.set(id, label+' ('+str(count)+')',url)
                    else:
                        config.set(id, label, url)
                        count = 0
        dp.update(75, 'writing to ini')
        with open(filename, 'wb') as configfile:
            config.write(configfile)
        dp.update(100, 'all done')
        dp.close()


@plugin.route('/update')
def update():
    if not sanitycheck('Update all addons?', 'Depending on your setup, this may take a while!'):
        return
    start = time.time()
    dp = xbmcgui.DialogProgress()

    if not plugin.get_setting('addons.folder'):
        dialog = xbmcgui.Dialog()
        dialog.notification("addons.ini Creator", "Set Folder",xbmcgui.NOTIFICATION_ERROR )
        xbmcaddon.Addon ('plugin.video.IVUEcreator').openSettings()

    folder = plugin.get_setting("addons.folder")
    file = plugin.get_setting("addons.file")
    filename = xbmc.translatePath(os.path.join(folder, file))
    dp.create('Updating links', "working...")
    dp.update(25)
    streams = {}

    config = ConfigParser.RawConfigParser()
    config.optionxform = str
    config.read(addons_ini_path)

    sections = config.sections()
    num_of_sections = len(sections)
    for section in sections:
        dp.update(30, 'Gathering '+ str(section) + '\'s streams, ' + str(num_of_sections) + ' of '+str(len(sections))+' to go')
        items = config.items(section)

        for item in items:
            path =  item[1]

            id = section
            if not id in streams:
                streams[id] = {}
            response = RPC.files.get_directory(media="files", directory=path, properties=["thumbnail"])
            files = response["files"]
            links = {}
            thumbnails = {}
            for f in files:
                if f["filetype"] == "file":
                    label = f["label"]
                    file = f["file"]
                    while (label in links):
                        label = "%s." % label
                    links[label] = file
                    thumbnails[label] = f["thumbnail"]
                    streams[id][label] = file

    dp.update(50,'links retrieved....')

    if plugin.get_setting("pvr.subscribe") == "true":
        streams["plugin.video.IVUEcreator"] = {}
        items = pvr()
        for item in items:
            name = item["label"]
            url = item["path"]
            streams["plugin.video.IVUEcreator"][name] = url

    dp.update(60,'getting xml channel labels....')
    config = ConfigParser.ConfigParser()
    config.optionxform = str

    config.read(filename)

    clean_names = get_clean_names()
    num_of_streams = len(streams)

    stream_count = 0
    for id in sorted(streams):
        dp.update(75, 'cleaning '+ id + ' links, '+ str(num_of_streams) + ' addons to go. '+ str(stream_count) +' links cleaned...')

        if config.has_section(id):
            config.remove_section(id)

        config.add_section(id)

        channels = streams[id]
        for channel in sorted(channels):
            url = channels[channel].strip()
            label = remove_formatting(channel.strip(), clean_names)

            if '<nolabel>' not in label:
                if config.has_option(id, label):
                    count += 1
                    config.set(id, label + ' (' + str(count) + ')', url)
                else:
                    config.set(id, label, url)
                    count = 0

    dp.update(90, 'writing links to .ini....')
    with open(filename, 'wb') as configfile:
        config.write(configfile)

    dp.update(100)
    dp.close()
    end = time.time()
    time_took = end-start
    m, s = divmod(time_took, 60)
    h, m = divmod(m, 60)


    message(str(stream_count) + ' streams added from ' + str(len(streams)) + ' addons in ' +  "%02d mins, %02d secs" % (m, s), 'Done!')




@plugin.route('/search/<what>')
def search(what):
    if not what:
        return
    addons = plugin.get_storage("addons")
    folder = plugin.get_setting("addons.folder")
    file = plugin.get_setting("addons.file")
    filename = os.path.join(folder,file)
    f = xbmcvfs.File(filename,"rb")
    lines = f.read().splitlines()
    addon = None
    for line in lines:
        if line.startswith('['):
            a = line.strip('[]')
            addons[a] = a
            addon = plugin.get_storage(a)
            addon.clear()
        elif "=" in line:
            (name,url) = line.split('=',1)
            if url and addon is not None:
                addon[name] = url

    items = []
    for a in addons.keys():
        add = plugin.get_storage(a)
        log2(add.keys())
        exact = [x for x in add.keys() if x.lower() == what.lower()]
        log2(exact)
        partial = [x for x in add.keys() if what.lower() in x.lower()]
        ignore_space = [x for x in add.keys() if re.sub(' ','',what).lower() in re.sub(' ','',x).lower()]
        found = exact + partial
        for f in sorted(set(exact)):
            items.append({
                "label": "[COLOR green]%s [%s][/COLOR]" % (f,a),
                "path" : add[f],
                "is_playable" : True,
            })
        for f in sorted(set(partial)-set(exact)):
            items.append({
                "label": "[COLOR orange]%s [%s][/COLOR]" % (f,a),
                "path" : add[f],
                "is_playable" : True,
            })
        for f in sorted(set(ignore_space)-set(partial)-set(exact)):
            items.append({
                "label": "[COLOR red]%s [%s][/COLOR]" % (f,a),
                "path" : add[f],
                "is_playable" : True,
            })
    return items
		
@plugin.route('/search_dialog')
def search_dialog():
    dialog = xbmcgui.Dialog()
    what = dialog.input("Search")
    if what:
        return search(what)

@plugin.route('/')
def index():
    items = []

    items.append(
    {
        'label': "Subscribe",
        'path': plugin.url_for('subscribe'),
        'thumbnail':get_tv_path('tv'),

    })
    items.append(
    {
        'label': "Create",
        'path': plugin.url_for('update'),
        'thumbnail':get_tv_path('tv'),
    })
	
    items.append(
    {
        'label': "Play ",
        'path': plugin.url_for('player'),
        'thumbnail':get_tv_path('tv'),
    })
    items.append(
    {
        'label': "Search",
        'path': plugin.url_for('search_dialog'),
        'thumbnail':get_tv_path('tv'),
    })
    items.append(
        {
            'label': "Update Single addon",
            'path': plugin.url_for('updateaddon'),
            'thumbnail': get_tv_path('tv'),
        })
	
    items.append(
        {
            'label': "Delete Single addon",
            'path': plugin.url_for('deleteaddon'),
            'thumbnail': get_tv_path('tv'),
        })
    items.append(
    {
        'label': "Unsubscribe",
        'path': plugin.url_for('clear'),
        'thumbnail':get_tv_path('tv'),
    })

    return items

if __name__ == '__main__':
    plugin.run()

